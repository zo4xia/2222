# 项目实时状态 (PROJECT_STATE.md)
> 根目录 = `clean-package/`，以下路径均相对本目录。
> 最后更新：2026-09-17 —— 本轮为**过期项更正 + 断档补齐**，以 `git log/diff` 取证为准。

## 1. 当前真实阶段
- 五阶段重构流水线（决策 #001）：阶段一 勘探 → 二 诊断 → 三 骨架 → 四 管线 **已完成并留痕**。
- **阶段五 · 精装验收（冒烟 / test_report / P0-P4 评级）仍未执行**。原文件写"准备进入阶段五"属实，但后续重心已切走，不得误读为已完成。
- 03:51 之后的实际重心：运行时止血 → 首屏性能 → 首页白屏修复 → **首次真实跑通交付** → UI 收口 → Agent B 去冗余。
- 客观状态：主链（识别 → 生成 → 质检 → 交付打包）已跑通并产出真实产物；收尾项（图片题断链 / Vercel 缺口 / 硬编码密钥 / 字体真源不一致 / row-player 规则全页统一）**未闭环**。

## 2. 已产出交付物
- 阶段文档：`project_initial_state.md`、`resource_list.md`、`risk_matrix.md`、`diagnostic_report.md`、`calibrated_prd.md`、`module_dependency_graph.md`、`decoupling_strategy.md`、`dataflow_diagram.md`、`api_spec.yaml`。
- **首次真实交付产物**（推翻"产物层为零"旧结论）：`public/deliverable/current.html`（5.15 MB，内嵌板书字体）、`current.json`（23.8 KB）、`deliverable-deliverable-1789584993949.html/json`、`deliverable.schema.json`、`DELIVERABLE_API_SPEC.md`。
- 运行时资产：`public/board-result/` 39 个、`public/handoff/` 20 个、`public/pic/` 截图、`public/audio/`。

## 3. 变更树（2026-09-17 全天，倒序）
```
row-player.html                             [~ stage 标签定位改读导出物 boardPlan 四个 Label（新增 resolveTagAnchor，删内容锚反推）；DEMO 补 Label 字段；规格批注同步]  ★未提交
server/agentBV2Handler.js                   [~ 合同失败回灌提示按类型分诊（新增 buildRepairHint/looksTruncated）+ 附坏输出尾部 + warn 留痕与 diagnostic 补全]  ★未提交
src/agent-b-v2/AgentBDirect.vue            [~ 折叠入口三重重复收口：删工具条3芯片(模板30行+CSS43行)，保留表头+单元格入口；"展开 ◀▶"→"展开"]  ★未提交
src/components/Step1Entry.vue              [~ 补 QUESTION_FONT_SIZE 导入；全屏预览3入口→1；删写死 min-height(420/560)；RealBoardPreview 改异步；色值 token 化；两栏平衡；知识卡紧凑化]
src/components/BoardContentLayer.vue       [~ ResizeObserver / measureTopic 加 null 防护，修首页白屏 getBoundingClientRect]
src/agent-b-v2/DirectFlow.vue              [~ AgentBDirect 改 defineAsyncComponent 按需加载]
src/agent-b-v2/serializeDeliverableState.js[+ 交付物序列化纯函数模块抽取（输出契约不变）]
src/utils/superFilter.js                   [~ 字号硬编码改 import stepHandoff 常量；删自造 compactBoardFontSize；控制字符正则加 eslint-disable]
src/utils/mathText.js                      [- 删死代码 normalizeLatexControlChars（真源在 superFilter.cleanTextEscapes）]
src/lib/apiConfigStoreFactory.js           [+ 通用配置工厂]
src/lib/{userApiConfig,agentBApiConfig,checkAgentApiConfig}.js [~ 三份同构配置收口]
src/services/{ttsService,deliverableService,cleanupService,knowledgeRefineService,stepHandoff}.js [+ 统一服务层 / +fetchCurrentHandoff]
server/checkAgentHandler.js                [~ changes 对比 board 归一化，修断言偏差 4!==1]
server/deliverableStoreHandler.js          [~ 交付物落盘链路]
server/smokeTest.js                        [~ 冒烟脚本]
public/deliverable/*                       [+ 首次真实产物]
PROJECT_STATE.md / ENGINEERING_LOG.md / DECISIONS.md [~ 三份记录同步]
.codebuddy/memory/2026-09-17.md / MEMORY.md[~ 工作记忆与长期红线]
```

## 4. 过期结论更正
| 原记录（已过期） | 更正后 |
|---|---|
| `public/deliverable/` 0 文件，整条链从未产出 | **作废**：现有 6 个文件，首份真实产物 5.15 MB 已落盘 |
| `AgentBDirect.vue` 在 `src/components/` | 实为 `src/agent-b-v2/AgentBDirect.vue`（168 KB / 5200+ 行） |
| 阶段四完成 = 准备进入阶段五 | 阶段五**仍未执行**，中间插入运行时修复与 UI 收口 |
| 验证真空（无 test / 无 self-check 总入口） | 仍成立，但已有可人工点检的真实样本 `public/deliverable/current.html` |

## 5. 未闭环风险与挂起项
- **P0 1h2g 内存风险（2026-09-17 新增，服务器规格 1 核 2G）**：`server/productionServer.js:98` `res.end(readFileSync(filePath))` 与 `server/renderDeliverableHtml.js:57` 读取交付页模板 —— 均为「整文件进内存」，无流式/无缓存头，并发即 OOM。见决策 #007。（2026-09-17 晚：模板已从 5.26 MB 瘦到 **0.11 MB**，压力降一个数量级；流式改造仍待排期）
~~**P0 板书落点 `board.startCoord` 未被消费（2026-09-17 新发现）**：`row-player.html:310-311` 组 board 计划项时未传 `coord`；`drawWriting` 读 `task.coord`（:616）→ `parseCoord(undefined)` → 退化默认 `{x:8,y:44}`。**所有板书叠在同一点，JSON 带 startCoord 也无效** → 盲测第 4 问必然挂~~ → **2026-09-17 PM 已修复**：`compile()` 已传 `coord: resolveBoardCoord(r, bp, r.stage)`，三层回退（startCoord > boardPlan[stage] 区左上角 +2%,+4% > 常量 {8,44}）落地（row-player.html:299-323），SPEC 7.4 已标过期更正，详见 memory/2026-09-17.md「规范对齐」段。
~~**P0 图片题断链**：`sourceImageUrl`/`screenshotUrl` 零消费，图片题的图在交付页必然丢失~~ → **2026-09-17 PM 已修复**：三层数据通链闭环——① `renderDeliverableHtml` 新增 `inlineDeliverableImages`（`/pic/` 相对路径自动内嵌 base64，缺文件保留原值+告警，1MB 体积护栏）② `row-player.html` normData 提取 `screenshotUrl` + 注入/JSON 导入/load 三装载点统一挂载 ③ render 幂等绘制 `boardPlan.image` 落区（x/y/w%，高度纵横比 clamp 底界 96.33%）。**前置条件：源图须存于 `public/pic/`**（现存 /pic/ 目录为空属运行时数据缺失，非代码阻断；补文件后自动恢复）。产物 current.html 已重生成验证（117KB，35px/三层回退/题图链路全落地）。
- ~~**P0 硬编码密钥**：`server/fishAudioHandler.js:12-14` 明文 `sk-fish`，`getApiKeys()` 无条件混入。~~ → **2026-09-17 PM 作废（用户指示）**：「预设的账号秘密是专门演示的，绝对不要删掉」——`DEFAULT_API_KEYS` 原样保留，此 P0 注销，禁止按旧记录执行移出操作。
- **P1 Vercel 部署缺口**：`vercel.json` 只覆盖 6 个 api 文件，缺 tts/handoff/deliverable/knowledge/screenshot/cleanup → 线上 404。
- ~~**P1 字体真源已拍板（2026-09-17，见决策 #006）**：本地自托管为准，CDN 仅作可选~~ → **2026-09-17 晚作废，见决策 #008**：交付页由客户自己的 Agent 生成、产物要给外部 API/Agent 做 skills，因此**字体必须走 CDN，禁止内嵌**；本地 `pingfang-qiaomu.ttf` 仅留作历史资产。
  - 已落地：交付页/设计灵感卡片/两份历史 deliverable HTML 的内嵌字体段全部删除，改引 `https://fontsapi.zeoseven.com/507/main/result.css`（平方乔木体）。
  - 体积结果：`row-player.html` 5.01 MB → **0.11 MB**；`public/deliverable/*.html` 5.03 MB → **0.12 MB**。
  - **素材（底图/贴纸/背景）仍必须内嵌 base64**：禁止任何相对路径外链 —— 产物要能脱环境双击打开。
- **P1 row-player 排版与落笔规则全页统一**：用户要求"所有页面都需要 row-player.html 里专门设计的规则"，**尚未执行**。
~~**P1 板书字号三处不一致（2026-09-17 sub 复核发现，待拍板）**：真源 `src/services/stepHandoff.js:16` `BOARD_FONT_SIZE = 35`（推荐文案却写"1.2~1.5 倍，推荐 35px"，35/30=1.17 与下限自相矛盾）；`row-player.html:618` 写死 `size=42`（注释自称 ×1.4）；`MEMORY.md` 记的是"1.5 倍"。三者互不相同，撞单一真相红线。**未擅自改**（属画布渲染观感，用户未要求）。候选：A 统一到 35（row-player 的 42 及 `document.fonts.load`/测宽的 42 共 4 处同步）；B 真源改 42；C 登记为独立边界镜像 + 同步责任。~~ → **2026-09-17 PM 已拍板执行候选 A**：统一 **35px**（真源 `stepHandoff.js` `BOARD_FONT_SIZE` 不变），`row-player.html` 四处 42→35（drawWriting size / fonts.load 预热 / measureText ×2）+ 规格批注字体名更正为平方乔木体；MEMORY.md 字号条目已标过期更正。35px 手写感需重生成产物后人工点检。
- **P2 记忆与 DIGEST 归属（待拍板）**：上层仓库 `.codebuddy/memory/CONTEXT-DIGEST.md`（2026-09-15）是**旧工作区口径**（`src/main.js` 主链路、vite build 必挂、3000 属别的项目），与决策 #003「上层是脏区、不维护不引用」冲突；clean-package 下**没有** DIGEST。取舍：废弃上层 DIGEST / 或在 clean-package 新建并指定 owner。
- **P2 孤儿文件**：`lite-player.html` 全仓 0 引用；仓库上层 `设计灵感卡片-row-player.html` 有 342+/85- 未提交改动，来源待确认。
- **P2 运行时写 `public/`** 共 6 处（audio/pic/handoff/board-result/deliverable/knowledge），线上持久化方案未立。

## 6. 下一步接力棒
1. 阶段五 · 精装验收：跑全链路冒烟，产出 `test_report.md` + P0-P4 评级，P0 清零。
2. ~~字体真源拍板~~ → **已完成（决策 #008：字体走 CDN、素材内嵌；交付页 5.01 MB → 0.11 MB）**。后续：① 应用内 490 与交付页 507 统一为同一字族（书同文）② 落地符号降级规则（决策 #009）。
3. row-player 排版与落笔规则全页统一（待上条拍板后一并执行）。
4. 图片题断链修复、Vercel 配置补全、密钥移出代码。
5. **Agent B 软修缮真实联调**（决策 #011）：带一份坏输出（截断 / fence 包裹）跑一次 `/api/agent-b-v2/generate`，确认模型回灌后确能修好；目前只有静态分诊验证。
6. **交付页标签人工点检**：换一份 `layoutMode=landscape-top-image` 的导出物打开 `row-player.html`，确认四标签随导出物落位、书写区不再错位（`row-player.html` 不进 build，无法靠 `npm run build` 验证）。
