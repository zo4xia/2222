# 项目长期记忆
> 更新日期：2026-09-17

## 记录维护铁律（用户反复强调，务必每次执行）
- **任何改动必须留痕，没落痕迹就等于没做。** 收工前必须同步三份记录（均在 `clean-package/` 根目录）：
  1. `ENGINEERING_LOG.md`：做了什么 + 验证结果 + 排除项 + 接力棒；
  2. `PROJECT_STATE.md`：当前状态 + 变更树（以 `git status/diff` 取证，不凭记忆）+ 未闭环风险；
  3. `DECISIONS.md`：为何这么做（决策/红线/待拍板）。
- **工作根目录 = `clean-package/`**（上层仓库的同名记录是历史，不作为真相源）。
- 发现有过期结论时，**当场在 `PROJECT_STATE.md` 用「过期结论更正」表格标注作废**，不要静默覆盖。
- **用户口述的要求必须「当场」写进 `MEMORY.md`，不许拖到收工再补**（2026-09-17 教训：同一条要求用户重复强调不下 20 次才落笔，引发强烈不满）。听到"必须/一定/记住/写到记忆"这类话，立刻停下手上的活先写入，再继续干活。
- **沟通默认全程降噪**（2026-09-17）：只输出必要结论、证据、变更、验证结果和风险；不复述背景，不输出过程性废话。

## 最高工程处事规则：统一法度，单一真相（2026-09-16）
- 代码和工程实行“罢黜百家，车同轨、书同文”：同一模块、参数、业务规则、过滤、归一化或职责，只允许一个权威定义和一条主执行链。
- 公共真源负责定义规则，各地模块负责调用和执行；不得各自发明口径、重复实现、私设旁路或用 `New`、`V2`、`Temp` 逃避统一。
- 既有实现不足时，直接修正原真源并同步所有合法边界镜像；独立运行边界仅允许保留必要的等价镜像，且必须遵守同一规则、同一验收标准并记录同步责任。
- 新增术语、状态、参数、例外和抽象必须就近定义归属、范围、依据与影响；未经定义和验收的地方性规则不得进入主线。
- 一切改动先以事实审计和交叉证据确认，再按责任边界实施；关键决策、排除项、验证结果、风险和未完成事项必须留痕。

## 播放器链路责任与护栏（2026-09-16）
- 唯一播放器模板真源 = 项目根 `row-player.html`（`server/renderDeliverableHtml.js` 指定，注入 `window.__INITIAL_DELIVERABLE__`）；`lite-player.html` 全仓无引用，是孤儿文件，不作为依据。
- 音频生成由用户**逐行手动点击**触发，不做自动预生成/抢拍；未生成前播放必须有门禁。（2026-09-16 已在 `lite-player.html` 落地：删自动预生成 + `startPlay` 门禁，谓词与预生成筛选一致 `r.speech && !r.audioUrl`；`row-player.html` 交付页本身无预生成逻辑）
- 音频缺失或加载失败 → 走无声时钟继续，不得卡死。（2026-09-16 已修复：`row-player.html` 新增 `audioEl.onerror` 兜底 + `isAudioSrc()` 地址白名单，占位字面量不再被当 mp3 路径）
- **无音频播放原生兜底机制（2026-09-16 确立）**：
  1. **虚拟时钟切流**：无音频或音频为空时 `rowHasAudio=false`，自动降级为 `performance.now() - rowT0` 虚拟时钟驱动，`now() >= rowAnchor + durMs` 自动顺滑切行，全流程自闭环推进，不卡死；
  2. **四级时长兜底**：`audioDurationMs` > `duration * 1000` > 语速估算（160字/分） > 板书动作最晚结束时间（`maxEnd`），确保无声态下板书与圈画依然按真实节奏从容播完；
  3. **失效地址安全网**：非音频文本被 `isAudioSrc()` 过滤为空；若遇 404/加载异常由 `onerror` 立即切回虚拟时钟并补 `rAF`。
- 时长真源优先级：`audioDurationMs`（毫秒）> 估算时长；展示/导出秒制 `duration` 必须与主时钟同源。（2026-09-16 已修复：`normRow` 的 `duration` 归一链已补 `audioDurationMs/1000` 回退）
- 未生成音频时写字面量占位是错的，应写空值并显示"待生成"，不得显示伪造秒数。（2026-09-16 已收口：原 4 处 `音频暂未生成` 字面量已全部改空串，仅注释中留说明文字）
- 只改 CSS 变量与默认值，不改现有 DOM 类名与结构；画布区（`--board`、`.stage`、`canvas#board/#ink` 1726×980）锁定不动。

## clean-package 音频字段职责
- Agent B 模型合同：使用 `audioUrl` + `audioDurationMs`；模型不生成或估算 `mp3` / `duration`。
- 下游导出合同：必须提供 `screenshotUrl`、`mp3`、秒制 `duration`；可保留 `audioDurationMs` 作为毫秒真源。
- 导出边界负责把运行时字段映射为播放器交付字段：`audioUrl` → `mp3`，`audioDurationMs / 1000` → `duration`。
- **音频本地持久化与对外链接闭环**（2026-09-16 确立）：外部音频/第三方 CDN 有时效和防盗链限制，严禁对外抛出外部临时 URL。服务端（`server/fishAudioHandler.js`）抓取合成后必须写盘归档至本地（`public/audio/` 与 `public/audio-cache/`）。Agent B 点击下载的配套 JSON（`deliverable-*.json`）中，`audioUrl` 及 `mp3` 必须是且已是本地静态服务托管链接（如 `/audio/audio-xxxx.mp3`），实现资源持久化与交付自闭环。
- `screenshotUrl` 是原题截图的持久资产来源，不依赖临时 `blob:` URL。
- 音频必须完整播放，禁止用估算时长、定时器、`currentTime` 重置、裁剪或导出回退逻辑人为截断；播放完成以原生 `ended` 事件或用户主动停止为准。
- 交付验收必须同时检查音频完整播放、首屏速度、非关键资源懒加载和非关键 JavaScript 异步/延迟加载。

## 板书渲染方案
- 方案 1（已确认）：事前完整排版板书成品，覆盖白色遮罩；按语音时间让遮罩以手写感逐行消失/擦除，适合画图项目。
- 方案 1 与实时逐字生成是两种独立渲染策略。

## 运行环境与性能约束（长期有效）
- **演示服务器规格 = 1 核 2G（1h2g）**（2026-09-17 用户告知）。所有方案按此评估：内存与带宽都是硬约束。
- 因此：**能走 CDN 就走 CDN（大陆 CDN 优先）**，能流式就别整文件读；MB 级资源（字体 3.68 MB、交付页 5.26 MB、音频、截图）禁止 `readFileSync` 后进 `res.end()`。
- 静态资产真源在 `public/`；`dist/` 是构建产物；**上层仓库目录是脏历史区，不维护、不引用**。
- **字体不再内嵌**（2026-09-17 拍板）：交付页/应用内一律走 CDN，本地 `pingfang-qiaomu.ttf` 仅作历史资产保留，不再进入产物。

## 交付产物脱环境铁律（2026-09-17 用户拍板，最高优先级）
- **背景**：交付页是**客户自己的 Agent 生成的**，产物要喂给**外部 API 和 Agent 做 skills**。所以产物必须「脱环境、自包含、拿出去就能双击打开」。
- **字体：必须走 CDN，禁止内嵌**（用户原话："我们必须用 CDN"）。大陆 CDN 优先，接入方式官方唯一写法：
  - 平方乔木体：`https://fontsapi.zeoseven.com/507/main/result.css`，`font-family:"平方乔木体"`
  - 栗壳坚坚体：`https://fontsapi.zeoseven.com/490/main/result.css`，`font-family:"LikeJianJianTi"`
  - 只需一行 `<link rel="stylesheet" href="...result.css">`（CSS 内含分片 @font-face，按需加载），**不要自己写 @font-face 指向 ttf**。
- **素材：必须内嵌 base64**（底图/贴纸/背景一律 data URI），**禁止任何相对路径外链**（`public/fonts/xxx.ttf`、`./pic/xxx.png` 一律视为违规 —— 离开项目目录即 404）。
- 体积结果：`row-player.html` 5.01 MB → **0.11 MB**；`public/deliverable/*.html` 5.03 MB → **0.12 MB**（删掉 5,149,880 字符的内嵌字体段）。
- 产物生成链路：`AgentBDirect.vue:1366`「打开刚固化归档的自包含单页（row-player 模板 + 注入 JSON）」→ **改 row-player.html 模板 = 改产物**，历史产物另需单独回溯处理。
- 验收三问：① 双击打开是否有画面（素材内嵌）② 是否有本地相对路径请求（应 0 条）③ 体积是否 < 1 MB。

## 板书特殊符号降级规则（2026-09-17 用户指示）
- 手写字体字库覆盖不全，**缺的符号用常见字符自己凑**，不要硬写生僻符号（会出豆腐块）：
  - 乘号 → 英文字母 `x`
  - 除号 → **分数写法**（分子/横线/分母上下排），不用 `÷`
  - 上下带点的符号（如 `∵` `∴` 一类）→ 用**英文句点 `.` + 短横 `-` 上下排版**凑
- 落地位置：`src/utils/superFilter.js`（"车同轨书同文"超级过滤器，文本统一过这一层）+ `row-player.html` 渲染侧；规则只此一份，不得各处各写。

## 字体 CDN 官方资源索引（2026-09-17 用户提供，长期有效）
- 字体服务 = **ZSFT / ZeoSeven Fonts**（大陆 CDN，免费商用，分片按需）。
- 常用入口：
  - `https://fontsapi.zeoseven.com/490/main/result.css` → 栗壳坚坚体 `LikeJianJianTi`
  - `https://fontsapi.zeoseven.com/507/main/result.css` → 平方乔木体 `平方乔木体`
  - 字体详情页：`https://fonts.zeoseven.com/items/490/`（含 `#/maps` 字符映射、`#embed` 嵌入写法、字符统计、授权范围）
  - CLI：`https://fonts.zeoseven.com/docs/cli/` —— `npm i -g zsft`，可对字体做**子集化 / 转换 / 拆分**（基于 fonttools + cn-font-split），需要本地压体积时用它。
  - npm 包：`zsf`（ZSFT 相关）；另有字形截取工具 `https://fonts.zeoseven.com/camera/`。
- 授权要点：可商用、可嵌入集成；商标禁用；再分发需带协议副本。

## 输出物合格标准 = 盲测线（2026-09-17 决策 #012，长期有效）
- 判定：**零上下文 Agent + 一份 deliverable JSON + `row-player.html`，能演完整任意一题 = 合格**。倒推法：演不出来的就必填。
- 必带三层：① 题目层 `problemText` + `boardPlan`（canvas 1726×980、layoutMode 三值、四区、**四个 Label**、image）；② row 层 `stage`(四值)/`speech`/`board.content`/`board.startCoord`/`board.startDelay|triggerKeyword`/`duration|audioDurationMs`/`mp3`(未生成写"")/可选 `actionSpec`；③ 验收六问。
- **四区范围 + 四个 stage 标签坐标 = 「本题目参数信息」，整块照搬导出物，禁止写死、禁止用板书内容反推。**
- 字体不进 JSON，模板侧决定：CDN 490（栗壳坚坚体 `LikeJianJianTi`）与 507（平方乔木体）**都可用**，现用 507。
- 真源：`public/deliverable/deliverable.schema.json` + `DELIVERABLE_API_SPEC.md` 第七节（含最小可播 JSON 骨架）。**不建第二份规范**，`dist/` 是构建产物不动。
- **P0 未修（待拍板）**：`row-player.html` 的 `compile()` 未把 `coord` 传进 board 计划项 → 板书落点恒为默认 `{x:8,y:44}`，所有板书叠一处，盲测必挂。修法：`compile()` 带 coord，优先级 `board.startCoord` > `boardPlan[stage 区]`左上角 > 模板常量（与 `resolveTagAnchor` 三层回退对齐）。

## 关键文件定位（易踩坑）
- 第 1 步首页 = `src/components/Step1Entry.vue`；第 2 步「Agent B 工作室」= `src/agent-b-v2/AgentBDirect.vue`（168 KB，**不在** `src/components/`）；画布落座 = `src/utils/boardLayout.js` + `src/components/BoardContentLayer.vue`。

## UI 视觉偏好（甲方，长期有效）
- **画布与板书渲染区不许动**：`1726×980` 画布、板书画布、纸白底色（`#fbfaf6`）、画布容器边框属锁定范围，任何美化不得进入。
- **加载态（loading）不许改**（2026-09-17 用户明确指示"loading 别改"，覆盖此前"加载态可自由美化"的旧说法）：所有 `:loading` 绑定、加载遮罩、骨架屏维持现状，UI 优化一律不得触碰。
- 其余界面（外壳、导航、卡片、按钮）可自由美化。
- 风格倾向：卡片式容器、圆润圆角、**按钮层级清晰**、工作台容器走**中平面**（轻层次、弱阴影、克制）。
- 单一视觉真源：`src/style.css` 的 `--qh-*` token；`row-player.html`（2026-09-17 决策 #008 后**已引 CDN 字体外链**，不再是"无法引外部样式"）是同真源的镜像，改色必须两处同步。
- 唯一播放器模板真源 = 项目根 `row-player.html`（`server/renderDeliverableHtml.js` 指定）；`备份/` 下的同名文件是旧备份，不改动。

## 验证边界（长期有效）
- `vite.config.js` 的 build 入口只有 `index.html` 与 `board-preview.html`：**`row-player.html` 不参与构建**。任何播放器改动无法靠 `npm run build` 验证，只能靠静态 lint + 运行时人工点检，交付前必须人工验一遍播放/批注/录制。
- `row-player.html` 是准离线单页：除** CDN 字体一条外链**（决策 #008）外无外部 script/link，首屏基本不受外部资源阻塞；交付数据由 `renderDeliverableHtml.js` 注入 `</head>` 前（同步执行）。
- ~~单文件离线 = 依赖必须内嵌~~ **（2026-09-17 作废，见下方「交付产物脱环境铁律」）**：字体已改为 CDN，不再内嵌 3.86 MB data URI。
- **素材（底图/贴纸/背景）仍必须内嵌 base64**（`ASSET` 常量，webp），交付页离开项目目录也要能出画面。
- 板书字风格唯一真源 = `handwrite-compare (3).html` 同款平方乔木体；`row-player.html` 字形抖动（字号/基线/字距）已归零，手写感只来自位置/旋转/行倾。

## 布局与落座约定（核心保护资产，严禁破坏）
- 设计画布为 `1726 × 980`。
- **A 画布自动落座算法（核心资产·绝对禁止改动）**：
  - 代码位置：`src/utils/boardLayout.js` (`planLabelsFromTopic`、`planPortraitLayout`、`planPortraitWithImageLayout`、`planLandscapeLayout`、`layoutBoardRows` 等) 及 `src/components/Step1Entry.vue` 结合 `BoardContentLayer.vue` 的自适应测高与落位链路。
  - 价值与红线：这是经过大量复杂排版推敲和精细试错磨合出来的核心资产（支持横图上下分排、竖图/纯文字左题右解三区分配、自然行高累加避让）。**任何优化、重构、精简、简化需求，严禁擅自改动、削减或重写 A 画布的自动落座判断逻辑与算法！**
- ~~题目使用微软雅黑 `30px`；板书字号按题目 `1.5` 倍；内容较多时解答区允许降至 `1.2` 倍~~ **【过期·2026-09-17 PM 更正】**：题目微软雅黑 `30px`；板书字号唯一真源 = `src/services/stepHandoff.js` `BOARD_FONT_SIZE`（**35px**，≈题目 1.2~1.5 倍区间推荐值）；`row-player.html` 四处已统一 35px，任何位置不得另立字号。内容不得溢出画布不变。
- **stage 标签定位唯一真源 = 导出物 `boardPlan` 的四个 Label**（2026-09-17 用户拍板，决策 #010）：`topicLabel / analysisLabel / solutionLabel / summaryLabel`。交付页必须**装载即读取**，禁止模板写死常量、禁止用板书 `startCoord` 内容锚反推——四区 stage 定位就是标签定位，取错则书写区域看着就错。回退顺序：Label > 该区左上角 > 模板常量。Label 坐标随 `layoutMode`（竖图/横图/左图）变化，写死必错。

## Agent B 输出容错（2026-09-17 用户拍板，决策 #011）
- 模型返回格式不对时**不得直接报错结束**：先把具体错误回灌给模型让它自行修缮重出（`server/agentBV2Handler.js` 的 `buildRepairHint`，话术按 `code` 分诊 + 附上一次坏输出尾部 600 字），仍失败才「尽力提取已闭合 rows」软降级，最后才是 422。
- 前端对合同类错误只发 warning 软提示并保留原 rows（`service.js` 标 `retryable`，`AgentBDirect.vue` 消费）；网络/鉴权/超时等非合同错误按原路径返回。
- `MAX_RETRIES` 保持 1，不擅自放大上游开销。截断判定看括号是否真未闭合（带引号转义），不能只看结尾字符。

## 工作区口径（2026-09-17 订正，防复发）
- 工作根 = `clean-package/`。**换工作区 = 换口径**：本区 `vite.config.js` dev port 就是 3000、`npm run build` 可用（入口 `index.html` + `board-preview.html`）；"3000 是别的项目 / 禁止 vite build" 只在旧工作区成立，勿套用到此。
- 唯一例外：`row-player.html` 不进 build 入口 → 播放器改动无法靠构建验证，只能静态 lint + 人工点检。
- **改模板 ≠ 改产物**：`public/deliverable/*.html` 不会自动回溯，验证标签/字号等模板改动前必须先重生成产物，否则看到的是旧行为、结论为假。

## 图片题链路（2026-09-17 PM 已通）
- 题图真源链：AgentBDirect 写入 screenshotUrl/sourceImageUrl → `renderDeliverableHtml` 的 `inlineDeliverableImages`（/pic/ 相对路径 → base64 data URL，脱环境铁律，1MB 体积护栏）→ `row-player.html` normData 提取 + load() 统一挂载 + render 幂等绘制 `boardPlan.image` 落区（x/y/w%，高度纵横比 clamp 底界 96.33%）。
- 缺图行为：源文件不在 public/pic/ → 服务端保留原值+告警，播放器 onerror 静默跳过图片层，文字板书不受影响。
- 现存 /pic/ 目录为空（运行时数据缺失）：补真实截图后自动恢复，图片题产物需人工点检落区视觉。
