# 文生视频 — 创建文生视频任务

## API 基本信息

| 项目 | 值 |
|------|-----|
| Plugin ID | `284585aa-3c6e-4827-b46e-a1e610aa3100` |
| API ID | `api-o9wN672BkyMa` |
| Endpoint | `POST https://app-egqhzg86bk01-api-o9wN672BkyMa-gateway.miaoda.online/beta/video/generations/kling/text2video` |
| 认证模式 | `platform_managed` |
| Auth Header | `X-Gateway-Authorization: Bearer ${INTEGRATIONS_API_KEY}` |
| Content-Type | `application/json` |
| 第三方域名 | `qianfan.baidubce.com` |
| 说明 | 创建任务接口负责提交任务请求，查询接口见 `query-api.md` |

---

## 请求参数表

> **说明：** APIDOC context 仅记录了 `prompt` 和 `duration` 两个参数，以下完整参数列表来自 Kling 原始 API 文档（与 SKILL.md 调用代码一致）。

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| `model_name` | string | 是 | — | 用于生成视频的模型，枚举值：`kling-v1`、`kling-v1-6`、`kling-v2-master`、`kling-v2-1-master` |
| `prompt` | string | 是 | — | 正向文本提示词，最大 2500 字符 |
| `duration` | string | 否 | `"5"` | 生成视频时长（秒），枚举值：`"5"`、`"10"` |
| `mode` | string | 否 | `"std"` | 生成模式，枚举值：`std`（标准，性价比高）、`pro`（高品质，效果更佳） |
| `aspect_ratio` | string | 否 | `"16:9"` | 视频宽高比，如 `"16:9"`、`"9:16"`、`"1:1"` |
| `negative_prompt` | string | 否 | — | 负向文本提示词，描述不希望出现在视频中的内容 |
| `callback_url` | string | 否 | — | 任务完成后的回调地址，任务状态变更时将 POST 通知到该 URL |

---

## 响应字段表

### 成功响应（HTTP 200，`code: 0`）

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `code` | number | 错误码，0 表示成功 |
| `message` | string | 错误信息，成功时为空字符串 |
| `request_id` | string | 请求 ID，用于排查问题 |
| `data.task_id` | string | 任务 ID，系统生成 |
| `data.task_status` | string | 任务状态：`submitted`（已提交）、`processing`（处理中）、`succeed`（成功）、`failed`（失败） |
| `data.created_at` | number | 任务创建时间，Unix 时间戳（单位 ms） |
| `data.updated_at` | number | 任务更新时间，Unix 时间戳（单位 ms） |

### 失败响应

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `code` | number | 非 0 的错误码 |
| `message` | string | 错误信息描述 |
| `request_id` | string | 请求 ID |

---

## 生成期代码（Agent 直接调用）

生成期（Agent 直接调用）已改为脚本调用方式，不再使用本节 API 的内联调用代码。具体命令示例见 `SKILL.md` 的"生成期用法（Agent 直接调用）"一节（对应脚本 `scripts/generate_text_to_video.py` 和 `scripts/query_text_to_video.py`）。

---

## Edge Function 代码

> **重要**：此接口为异步接口，Edge Function 必须在调用后立即将 `task_id` 返回给前端，
> 不可在 Edge Function 内部轮询。前端负责每 5 秒调用查询接口。

```typescript
// edge-functions/text-to-video-submit.ts
import { serve } from "https://deno.land/std/http/server.ts";

serve(async (req: Request): Promise<Response> => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  // --- 解析客户端请求 ---
  let prompt: string;
  let duration: string;
  let modelName: string;
  let mode: string | undefined;
  let aspectRatio: string | undefined;
  let negativePrompt: string | undefined;
  let callbackUrl: string | undefined;
  try {
    const body = await req.json();
    prompt = body.prompt;
    if (!prompt) throw new Error("Missing prompt");
    duration = body.duration ?? "5";
    modelName = body.model_name ?? "kling-v1-6";
    mode = body.mode;
    aspectRatio = body.aspect_ratio;
    negativePrompt = body.negative_prompt;
    callbackUrl = body.callback_url;
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  // --- 注入平台密钥（严禁暴露到前端） ---
  const apiKey = Deno.env.get("INTEGRATIONS_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ error: "Server configuration error" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }

  // --- 调用上游接口 ---
  const requestBody: Record<string, unknown> = { model_name: modelName, prompt, duration };
  if (mode !== undefined) requestBody.mode = mode;
  if (aspectRatio !== undefined) requestBody.aspect_ratio = aspectRatio;
  if (negativePrompt !== undefined) requestBody.negative_prompt = negativePrompt;
  if (callbackUrl !== undefined) requestBody.callback_url = callbackUrl;

  const upstream = await fetch(
    "https://app-egqhzg86bk01-api-o9wN672BkyMa-gateway.miaoda.online/beta/video/generations/kling/text2video",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Gateway-Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify(requestBody),
    }
  );

  // 转发配额超限 / 余额不足错误
  if (upstream.status === 429 || upstream.status === 402) {
    const errText = await upstream.text();
    return new Response(errText, {
      status: upstream.status,
      headers: { "Content-Type": "application/json" },
    });
  }

  if (!upstream.ok) {
    return new Response(
      JSON.stringify({ error: `Upstream error: ${upstream.status}` }),
      { status: 502, headers: { "Content-Type": "application/json" } }
    );
  }

  const data = await upstream.json();
  // 立即返回 task_id，不轮询
  return new Response(JSON.stringify(data), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
});
```

---

## 前端调用代码

### Web 平台

```typescript
/**
 * 提交文生视频任务（Web 前端）
 * @param prompt - 正向文本提示词
 * @param duration - 视频时长（秒），枚举值："5"、"10"
 * @returns task_id，供后续轮询使用
 */
async function submitTextToVideoTask(
  prompt: string,
  duration: "5" | "10" = "5"
): Promise<string> {
  const { data, error } = await supabase.functions.invoke("text-to-video-submit", {
    body: { prompt, duration },
  });
  if (error) throw error;
  if (data.code !== 0) throw new Error(`API 错误 ${data.code}：${data.message}`);
  return data.data.task_id;
}
```

### MiniProgram 平台

```typescript
/**
 * 提交文生视频任务（MiniProgram 前端）
 * @param prompt - 正向文本提示词
 * @param duration - 视频时长（秒），枚举值："5"、"10"
 * @returns task_id，供后续轮询使用
 */
async function submitTextToVideoTask(
  prompt: string,
  duration: "5" | "10" = "5"
): Promise<string> {
  const { data, error } = await supabase.functions.invoke("text-to-video-submit", {
    body: { prompt, duration },
  });
  if (error) throw error;
  if (data.code !== 0) throw new Error(`API 错误 ${data.code}：${data.message}`);
  return data.data.task_id;
}
```

---

## 注意事项

- **密钥安全**：`INTEGRATIONS_API_KEY` 仅可在 Edge Function 服务端读取，严禁暴露到前端。
- **异步设计**：Edge Function 必须立即返回 `task_id`，不可在函数内轮询，避免超时。
- **错误处理**：务必处理 429（配额超限）和 402（余额不足）。
- **调用注意**：创建任务接口负责提交任务请求；请避免重复提交，以免产生重复任务。
