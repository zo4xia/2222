# 来源与适配范围

https://github.com/anthropics/skills/tree/main/skills/slack-gif-creator

Revision: 41bbe19d1a1a7eaab5e7bb9050a417e5c6cffc8f

原 Python 组帧、编码和验证工具：按 Apache-2.0 原样保留。浏览器编码：重写，明确调色板、透明和大小边界。未纳入 Slack 登录上传，不保证平台接收。

新增模块为独立实现，见 NOTICE、LICENSE。保留的上游英文资料/代码沿用原授权。实际测试范围以包外验证报告为准，本地通过不代表 QA 已加载、模型已接通或应用已发布。
