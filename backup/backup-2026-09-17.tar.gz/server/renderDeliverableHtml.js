import { readFileSync, existsSync } from 'fs'
import { resolve, dirname } from 'path'
import { fileURLToPath } from 'url'
// 车同轨、书同文：对外交付物统一过全局唯一超级过滤器，并带上统一规格批注
import {
  superCleanBoardField,
  cleanTextEscapes,
  renderSpecAnnotationComment,
} from '../src/utils/superFilter.js'

const __dirname = dirname(fileURLToPath(import.meta.url))
// 唯一模板 = 项目根 row-player.html（夏夏定版：单文件、零依赖、离线双击可开）
const playerTemplatePath = resolve(__dirname, '../row-player.html')

/**
 * 图片题脱环境内嵌（红线：交付素材禁止相对路径外链）：
 * screenshotUrl / sourceImageUrl 若为 /pic/... 等站内相对路径，读文件转 base64 data URL；
 * 文件缺失时保留原值并告警（不阻断交付物流水线，播放器侧 onerror 静默跳过图片层）。
 */
function inlineDeliverableImages(deliverable) {
  if (!deliverable || typeof deliverable !== 'object') return deliverable
  const out = { ...deliverable }
  const publicDir = resolve(__dirname, '../public')
  for (const key of ['screenshotUrl', 'sourceImageUrl']) {
    const url = out[key]
    if (typeof url !== 'string' || !url.startsWith('/') || url.startsWith('//')) continue
    const filePath = resolve(publicDir, '.' + url)
    if (!existsSync(filePath)) {
      console.warn(`[renderDeliverableHtml] ${key} 指向的文件不存在，保留原值（播放器将跳过图片层）：${url}`)
      continue
    }
    const ext = (filePath.split('.').pop() || '').toLowerCase()
    const mime = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg'
    out[key] = `data:${mime};base64,${readFileSync(filePath).toString('base64')}`
  }
  return out
}

/**
 * 交付物 JSON 过超级过滤器：
 * - 口播 speech 只清错误转义与控制字符（不动口语毛料）
 * - 板书 board 走完整车同轨书同文：错误转义 / 多余换行 / 除号 ÷ / 分数 \frac / 乘号 x / 平方 ² 立方 ³
 * - 单个 row 组内板书一行一个，写完一个再写一个（lines 数组保留）
 */
function sanitizeDeliverable(deliverable) {
  if (!deliverable || typeof deliverable !== 'object') return deliverable
  const out = { ...deliverable }
  if (typeof out.problemText === 'string') out.problemText = cleanTextEscapes(out.problemText)

  if (Array.isArray(out.rows)) {
    out.rows = out.rows.map((row) => {
      if (!row || typeof row !== 'object') return row
      const next = { ...row }
      if (typeof next.speech === 'string') next.speech = cleanTextEscapes(next.speech)
      const board = superCleanBoardField(next.board?.content ?? next.board ?? '')
      next.board = {
        ...(next.board && typeof next.board === 'object' ? next.board : {}),
        content: board.content,
        lines: board.lines,
      }
      return next
    })
  }
  return out
}

/**
 * 统一微课与参数交付物单页生成器
 * 读取 row-player.html 模板，注入预置交付物 JSON 数据（window.__INITIAL_DELIVERABLE__）
 * 产物 = 单个自包含可播放 HTML，杜绝多套 HTML 页面分化
 */
export function renderDeliverableHtml(deliverable) {
  // 图片题脱环境：先过滤文本，再把 /pic/ 相对路径题图内嵌 base64（文件缺失保留原值并告警）
  const cleaned = inlineDeliverableImages(sanitizeDeliverable(deliverable))
  // 对外批注：画布尺寸 / 比例 / 题目字号 / 板书字号 / 本题 stage 四区坐标落座区间 / 越界与手稿风格
  const specComment = renderSpecAnnotationComment({
    zoneAnchors: cleaned?.boardPlan || cleaned?.zoneAnchors || null,
  })

  if (existsSync(playerTemplatePath)) {
    try {
      const template = readFileSync(playerTemplatePath, 'utf-8')
      const safeJson = JSON.stringify(cleaned || {}).replace(/</g, '\\u003c')
      const injectedScript = `<script>window.__INITIAL_DELIVERABLE__ = ${safeJson};</script>\n</head>`
      const withSpec = template.includes('</head>')
        ? template.replace('</head>', `${specComment}\n${injectedScript}`)
        : `${specComment}\n${template}`
      const totalBytes = Buffer.byteLength(withSpec, 'utf8')
      if (totalBytes > 1024 * 1024) {
        console.warn(`[renderDeliverableHtml] 交付物超 1MB 脱环境铁律：${(totalBytes / 1024).toFixed(0)}KB（优先检查题图 base64 体积）`)
      }
      return withSpec
    } catch (err) {
      console.error('[renderDeliverableHtml] 读取模板失败，降级重定向:', err)
    }
  }

  // 极简降级兜底：自动重定向到统一播放器（开发期由 vite 直接服务项目根 row-player.html）
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>青花布手绘板书微课演播</title>
  ${specComment}
</head>
<body>
  <script>window.location.href = '/row-player.html';</script>
</body>
</html>`
}
