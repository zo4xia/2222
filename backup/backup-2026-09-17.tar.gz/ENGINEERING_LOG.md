# 工程日志 (ENGINEERING_LOG.md)

## 2026-09-17 阶段一 · 勘探准备完成与资产盘点
- **背景**：根据项目重构标准协议，对 clean-package 开展系统级重构工作，全面遵循五阶段工作法。
- **思路**：严格执行 refactor-discovery 标准，先看清森林再动第一棵树；自顶向下执行 4 层 X-RAY 深度扫描与文档六维研读，输出资源清单、风险矩阵与初始快照。
- **执行步骤**：
  1. 扫描项目目录树与文件清单，统计代码量与模块规模（299个文件，JS/Vue 95个，Vue核心单文件11个）。
  2. 绘制模块依赖图与依赖拓扑，定位高扇入关键节点（userApiConfig, stepHandoff, roughDrawingTool, mathAsrConverter）。
  3. 识别并定位 6 大核心业务中枢（识别检索、教学编排、质检润色、板书绘图、独立播放器、TTS配音）。
  4. 研读关键函数实现与调用链，确认 ASR 中文转换规则、基线时间线排布算法与持久化机制。
  5. 研读六维文档，标明缺失项与现有依据（AGENTS.md、知识库快照）。
  6. 实施止血三板斧，产出风险矩阵（重点标记 5200+ 行组件、自检断言偏差与配置冗余）。
- **代码变更**：
  - 新建 project_initial_state.md（初始状态快照与 Mermaid 依赖图）
  - 新建 resource_list.md（可复用资源清单）
  - 新建 risk_matrix.md（风险矩阵与止血三板斧）
  - 同步更新 PROJECT_STATE.md、DECISIONS.md、项目实时架构模块图.md
- **发现和确认**：
  - src/agent-b-v2/AgentBDirect.vue 单文件高达 5292 行，是核心维护瓶颈，需在阶段三进行安全模块拆分。
  - server/agentAKnowledgeSelfCheck.js 运行 100% 成功（247 行知识点）。
  - server/proxySelfCheck.js 第 225 行在 Check Agent changes 预期上存在断言偏差，需在管线阶段修复。
- **验证结果**：
  - 四层深度扫描全部完成（校验点达成）。
  - node server/agentAKnowledgeSelfCheck.js 执行通过。
  - 所有交付物文件均落盘验证。
- **接力棒**：启动阶段二 · 深度诊断 (refactor-diagnosis)，进行目录职责标注、三层业务扫描与六维度 1-5 分评估。

## 2026-09-17 阶段二 · 深度诊断与六维评估完成
- **背景**：在勘探准备基础上，对项目各目录职责、三层架构（表现层/业务逻辑层/数据层）及质量六维度进行客观度量与归因。
- **思路**：严格执行 refactor-diagnosis 规范，以目录职责标注与三层业务扫描为工具，把代码质量转化为可排序的量化短板与优先级。
- **执行步骤**：
  1. 扫描全部 Vue 组件的 fetch 调用分布，定位跨层穿透点（AgentBDirect.vue 存在 10+ 处直连 fetch）。
  2. 对比配置模块，发现 userApiConfig / agentBApiConfig / checkAgentApiConfig 存在同构冗余。
  3. 按照六维度（可读性 3、可维护性 2、性能 4、安全性 4、可测试性 2、可扩展性 3）完成 1-5 分客观定级。
  4. 产出 diagnostic_report.md 与 calibrated_prd.md，校准重构优先级为 P0-P2。
- **代码变更**：
  - 新建 diagnostic_report.md
  - 新建 calibrated_prd.md
  - 同步更新 PROJECT_STATE.md、DECISIONS.md、项目实时架构模块图.md
- **验证结果**：六维度打分与需求校准 100% 达成（校验点达成）。
- **接力棒**：进入阶段三 · 骨架施工 (refactor-skeleton)，落实页面四分类与服务层解耦设计。

## 2026-09-17 阶段三 · 骨架施工与解耦设计完成
- **背景**：针对深度诊断中发现的表现层裸 fetch 跨层穿透与 API Config 三份冗余问题，实施骨架解耦与模块收口。
- **思路**：严格执行 refactor-skeleton 规范，落实页面四分类、单向依赖链确立与耦合点显式标记，通过工厂模式与服务层统一收口。
- **执行步骤**：
  1. 产出 module_dependency_graph.md，明确页面四分类（公共布局/业务页面/功能组件/UI组件）与单向依赖方向。
  2. 显式标记三大耦合点（CP-01 表现层裸 fetch、CP-02 配置同构冗余、CP-03 独立播放器逻辑漂移）并产出 decoupling_strategy.md。
  3. 实现 src/lib/apiConfigStoreFactory.js 通用工厂，重构 userApiConfig, agentBApiConfig, checkAgentApiConfig，对外保持 100% 接口兼容。
  4. 建立统一服务层（ttsService, deliverableService, cleanupService, knowledgeRefineService）。
  5. 运行 npm run build 验证构建，3217 个模块全部无报错打包通过。
- **代码变更**：
  - 新建 src/lib/apiConfigStoreFactory.js
  - 重构 src/lib/userApiConfig.js, src/lib/agentBApiConfig.js, src/lib/checkAgentApiConfig.js
  - 新建 src/services/ttsService.js, deliverableService.js, cleanupService.js, knowledgeRefineService.js
  - 新建 module_dependency_graph.md, decoupling_strategy.md
  - 同步更新 PROJECT_STATE.md、DECISIONS.md、项目实时架构模块图.md
- **验证结果**：新旧结构对比图已生成，耦合点已标记，npm run build 构建成功（校验点达成）。
- **接力棒**：进入阶段四 · 管线铺设 (refactor-pipeline)，打通黄金三角 API 并修复自检断言。

## 2026-09-17 阶段四 · 管线铺设与数据流治理完成
- **背景**：骨架立好后，需打通黄金三角 API，治理数据交互规则并修复单测自检断言偏差。
- **思路**：严格执行 refactor-pipeline 规范，黄金三角 API 优先接入，非核心 API 分批接入，校验数据流解耦，确保 API 严格通过 Service 层通信并统一错误处理。
- **执行步骤**：
  1. 梳理黄金三角 API（识别、生成、交付物）并绘制 Mermaid 时序图，产出 dataflow_diagram.md。
  2. 定义 OpenAPI 3.0 标准接口规范 api_spec.yaml，固化出入参和 { ok, data, code, error } 交互封套。
  3. 修复 server/checkAgentHandler.js 中 changes 逐行比对时的 board 归一化逻辑，彻底解决 server/proxySelfCheck.js 的断言偏差 (4 !== 1)。
  4. 运行 node server/proxySelfCheck.js 与 node server/agentAKnowledgeSelfCheck.js，验证全链路自检 100% 绿灯。
- **代码变更**：
  - 修改 server/checkAgentHandler.js（board 对比归一化）
  - 修改 src/services/stepHandoff.js（新增 fetchCurrentHandoff）
  - 新建 dataflow_diagram.md, api_spec.yaml
  - 同步更新 PROJECT_STATE.md、DECISIONS.md、项目实时架构模块图.md
- **验证结果**：
  - proxy self-check ok 验证通过
  - agent A knowledge self-check ok (247 rows) 验证通过
  - npm run build 构建验证通过（校验点达成）
- **接力棒**：进入阶段五 · 精装验收 (refactor-acceptance)，执行全链路冒烟测试、P0-P4评级与规范固化。

---

## 2026-09-17 运行时止血 · 首屏修复与首屏性能（补记，提交 8b107c5 / 6e070a5）
- **背景**：进首页即崩、首屏重组件同步加载拖慢首屏。
- **执行步骤**：
  1. `src/components/Step1Entry.vue:9` 补 `QUESTION_FONT_SIZE` 导入，修 `Uncaught ReferenceError`（computed 内使用未导入）。
  2. 删除 `src/utils/mathText.js` 中无消费者的 `normalizeLatexControlChars`（真源已迁至 `superFilter.cleanTextEscapes`）。
  3. `src/utils/superFilter.js` 控制字符正则加 `eslint-disable-next-line` 并注明理由（语义必要，非误报）。
  4. `src/agent-b-v2/DirectFlow.vue` 将 `AgentBDirect.vue`、`src/components/Step1Entry.vue` 将 `RealBoardPreview.vue` 改为 `defineAsyncComponent`，重依赖延后加载。
- **代码变更**：`src/components/Step1Entry.vue`、`src/utils/mathText.js`、`src/utils/superFilter.js`、`src/agent-b-v2/DirectFlow.vue`。
- **验证结果**：`npm run build` 通过，产出独立 `RealBoardPreview-*.js` / `AgentBDirect-*.js` chunk。
- **重要教训**：IDE `read_lints` 对 .vue 报 0 诊断不可信，验证一律以命令行 `npx eslint src --ext .js,.vue` 为准（当时真实 1050 条：56 error / 994 warning）。
- **接力棒**：首页白屏排查与交付物序列化收拢。

## 2026-09-17 首页白屏修复 · 交付物序列化模块收拢（补记，提交 92e809b）
- **现象**：首页白屏，`Uncaught TypeError: Cannot read properties of null (reading 'getBoundingClientRect')`。
- **根因**：异步组件与题目初始挂载时，`BoardContentLayer.vue` 的 `ResizeObserver` 回调与 `measureTopic` 未防 DOM 为 null。
- **代码变更**：
  - `src/components/BoardContentLayer.vue` 增加安全前置检查与可选链防护。
  - 新增 `src/agent-b-v2/serializeDeliverableState.js` 纯函数模块，`AgentBDirect.vue` 改为参数对接，输出契约（`$schema` / `exclusiveExecutionPlan` / 统计 / Check 状态）与原实现完全一致。
- **验证结果**：首页恢复正常，`npm run build` 通过。
- **接力棒**：首次真实跑通交付 + UI 收口。

## 2026-09-17 首次真实交付产物落地（补记，提交 4f1f2db 内）
- **事实更正**：此前记录的"`public/deliverable/` 0 文件、整条链从未产出"**已作废**。
- **已落盘**：`public/deliverable/current.html`（5.15 MB，内嵌板书字体）、`current.json`（23.8 KB）、`deliverable-deliverable-1789584993949.html/json`、`deliverable.schema.json`、`DELIVERABLE_API_SPEC.md`。
- **代码变更**：`server/deliverableStoreHandler.js`、`server/smokeTest.js`、`server/checkAgentHandler.js`（board 归一化，修断言 4!==1）、四个 `src/services/*`、三个 `src/lib/*ApiConfig.js` + 工厂。
- **验证结果**：`node server/proxySelfCheck.js` 与 `node server/agentAKnowledgeSelfCheck.js`（247 行）全绿；`npm run build` 通过。
- **意义**：首次出现可人工点检的真实样本，打破"无产物 → 无法验收"的死循环。

## 2026-09-17 UI 收口 · 首页去冗余与视觉统一（补记）
- **约束（用户拍板，已升级红线）**：画布不动、自动落座算法不动、loading 不改。
- **执行步骤**：
  1. 全屏预览 3 个入口（页头 / 卡片 extra / 工具栏）→ 只留卡片 extra，删 `FullscreenOutlined` 导入。
  2. 「识别并贴上画布」提升 `type="primary"`，新增 `recognizeBlockedHint` + tooltip 解释禁用原因。
  3. 删装饰性常驻 `a-alert`，语义并入副说明；三个卡片重复定义 border-radius/阴影 → 统一走 `style.css` 的 `.qh-surface-card`。
  4. 删除 `.board-viewport{min-height:420px}` 与 `.preview-card{min-height:560px}`，高度改由画布 `aspect-ratio:1726/980` 自然撑开（修"视口越窄留白越大"）。
  5. 题干 textarea rows 6→4、新增 `.board-empty-hint` 空态、知识卡按钮上提至 `#extra`、删 `a-divider`。
  6. 组件内写死色值统一替换为 `--qh-*` token 与品牌蓝 `rgba(29,78,216,*)`。
- **代码变更**：`src/components/Step1Entry.vue`、`src/style.css`（仅复用现有 token，未新增）。
- **验证结果**：eslint 无新增 error（4 个 `no-empty` 为既有）；`npm run build` 通过，main CSS 8.36→8.25 kB。
- **教训**：删类名前必须全局搜该类的所有 CSS 声明（本次 `.knowledge-chips` 有 3 份重复定义，差点误删 deep 覆盖）。

## 2026-09-17 去冗余 · Agent B 工作室折叠入口收口（未提交）
- **冗余点**：折叠某列有 3 个入口 —— 工具条 3 个 `col-toggle-chip`（含 `chip-dot`）、表头 `col-fold-trigger`、折叠态单元格胶囊。前两者 100% 同功能（同调 `toggleColumn`）。
- **处理**：删工具条副本（模板 30 行 + CSS 43 行：`.col-toggle-chip`/`:hover`/`.collapsed`/`.chip-dot`/`.off`/`.col-layout-right`/`.col-layout-sublabel`），保留表头（就近）与单元格入口；表头文案 `展开 ◀▶` → `展开`。
- **未动**：`setLayoutPreset` / `toggleColumn` 逻辑与三个预设本身；画布与 loading 未碰。
- **验证结果**：全仓无残留类名；eslint 仅 1 个既有 error（`navigator is not defined`，改动前既有）；`npm run build` 通过（7.90s）。
- **规则沉淀**：同一状态切换若有"工具条 + 表头/行内"两套入口，保留离作用对象最近的，删工具条副本。

## 2026-09-17 挂起未决（尚未动手，待拍板）
- ~~**字体真源不一致**~~ → **2026-09-17 晚已拍板并执行（见决策 #008）**：字体必须走 CDN，素材必须内嵌（下方新增条目）。"单文件离线 = 依赖必须内嵌"这条旧约束作废。
- **row-player 排版与落笔规则全页统一**：用户要求所有页面统一采用 `row-player.html` 的排版与落笔规则（含规格真相源/死规定），**尚未执行**。
- **P0 未闭环**：图片题断链（`screenshotUrl` 下游零消费）、`server/fishAudioHandler.js` 明文密钥、Vercel api 覆盖不全。

## 2026-09-17 交付产物脱环境改造 · 字体 CDN 化（已执行）
- **起因（用户拍板）**：交付页由客户自己的 Agent 生成，产物要给**外部 API 和 Agent 做 skills** → 必须"脱环境、拿出去双击就能用"；因此**字体必须走 CDN**（内嵌 3.68 MB 不可接受），素材必须内嵌。
- **做法（唯一官方接入方式，fonts.zeoseven.com 取证）**：一行 `<link rel="stylesheet" href="https://fontsapi.zeoseven.com/507/main/result.css">`（平方乔木体），CSS 自带分片 `@font-face` + `local()` 优先 + `unicode-range` + `font-display:swap`；不自己写指向 ttf 的 `@font-face`。
- **改动清单**：
  1. `row-player.html`：删内嵌 `@font-face`（base64 段 5,149,880 字符）→ 引 CDN 507；`HAND_FONT` 改为 `"平方乔木体","PingFangHand",KaiTi,STKaiti,"PingFang SC",serif`；`document.fonts.load('42px "平方乔木体"')` 同步。
  2. `设计灵感卡片-row-player.html`（上层根目录）：删 `@font-face{...pingfang-qiaomu.ttf}` 本地相对路径（脱环境后必然 404）→ CDN 507。
  3. `public/deliverable/current.html`、`deliverable-deliverable-1789584993949.html`：同法去内嵌。
- **验证结果**：`row-player.html` 5.01 MB → **0.11 MB**；产物 5.03 MB → **0.12 MB**；`data:font/ttf;base64` 残留 0；外链仅 CDN 一条；底图/贴纸素材（`ASSET` data:image/webp）保持内嵌。
- **链路事实**：产物 = `AgentBDirect.vue:1366`「row-player 模板 + 注入 JSON」→ 改模板即改产物；历史产物需单独回溯（本次已回溯处理）。
- **排除项**：未做字形子集化（CDN 已分片按需，无需）；`productionServer.js` 流式改造仍待排期（决策 #007）。
- **接力棒**：① 应用内 490（栗壳坚坚体）与交付页 507（平方乔木体）字族未统一，待一并改 507；② 符号降级规则（决策 #009）未实现。

## 2026-09-17 stage 标签定位改为「装载即读导出物」（已执行）
- **起因（用户）**：交付页的标签位置与题目标签必须一开始就读取导出物给的坐标——**四区 stage 定位就是标签定位**；不这样取，书写区域就是错的。
- **取证（两处独立证据）**：
  1. 真源 `src/utils/boardLayout.js:27-35` 与 `public/deliverable/current.json` 的 `boardPlan` **确实带四个标签字段** `topicLabel / analysisLabel / solutionLabel / summaryLabel`，且随 `layoutMode` 变化（横图模式实测：分析 (5.7,44.39)、解答 (36.37,44.39)、总结 (67.03,44.39)，与竖图默认值完全不同）。
  2. 改动前 `row-player.html` 的 `drawStageTag` **根本没读这些字段**：题目标签写死 `(2.5, 5)`；其余 stage 优先用「该 stage 首个 board 的 startCoord 内容锚」反推，兜底才读区域左上角 `boardPlan[key]`（不是 Label）→ 横图/左图模式下必然与落座错位。
- **改动（只动 `row-player.html` 唯一播放器母版）**：
  1. 新增 `resolveTagAnchor(bp)`：优先级 **Label 定位 > 该区左上角 > 模板常量**，`compile()` 装载期一次性解析进 `C.tagAnchor`（render(0) 起就在导出物给的位置，seek 幂等）。
  2. `drawStageTag` 删除内容锚反推分支，只保留弹出动画（只改尺寸、不改落点）；题目仍 t=0 常驻。
  3. 模板内嵌 DEMO `boardPlan` 补齐四个 Label 字段（与 `boardLayout.js` 默认值一致）；头部规格批注同步写明 Label 是真源。
- **排除项**：未动画布/落座算法；未对板书 `startCoord` 做越界重排（规格 4 允许自由越界）；未改 `ZoneAnchors` 兼容（`server/renderDeliverableHtml.js` 与 `normData` 本就以 `boardPlan` 为入口）。
- **验证结果**：抽取脚本 `node --check` 通过、lint 0；用真实产物 `current.json` 解析 → 四标签与导出物完全一致；空 `boardPlan` 回退常量不崩。

## 2026-09-17 Agent B 合同失败改为「软提示模型自行修缮」（已执行）
- **起因（用户）**：Agent B 返回内容格式不对时，不要马上报错结束，而是把错误软提示给模型，让它修缮后重出。
- **取证（先确认没被改坏）**：`git diff` 显示未提交改动只涉及 `row-player.html` / 三个入口 html / `main.js` / `superFilter.js`，**昨天的容错链全在** —— `server/agentBV2Handler.js` 重试循环、`src/agent-b-v2/service.js:58` 标 `retryable`、`AgentBDirect.vue:1128-1139` warning 软提示并保留原 rows。
- **真正的缺陷**：重试时回灌给模型的话术**写死只有 stage 同义词那一句**（`agentBV2Handler.js:289`）。JSON 截断 / 非 JSON / Markdown fence 包裹这类「格式不对」拿到的是不对症的指令 → 模型改不好 → 第二次仍失败 → 422 报错结束。
- **改动（只动 `server/agentBV2Handler.js`）**：
  1. 新增 `buildRepairHint()` 按错误类型分诊：`INVALID_STAGE` → 合法四值清单；`finish_reason=length` 或括号未闭合 → 判定截断，要求压缩口播/减行；其余 → 要求输出纯 JSON（禁 fence 与解释文字）、顶层 `{"rows":[...]}`。
  2. 回灌时附上一次坏输出**尾部 600 字符**，让模型能定位接续点；并要求重出完整表而非只改错行。
  3. 截断判定改用 `looksTruncated()` 括号闭合计数（带引号转义）—— 初版按「结尾字符」判定会把 Markdown fence 结尾误判为截断，已修正。
  4. 重试前 `console.warn` 留痕；422 `diagnostic` 补 `finishReason`、`retried` 不再只认 `INVALID_STAGE`。
- **排除项**：`MAX_RETRIES` 仍为 1（不擅自增加上游开销）；不改前端（软提示与保留 rows 已就位）；不改 `contract.js` 解析规则。
- **验证结果**：lint 0；四类场景分诊实测全部命中预期（stage 非法 / 真截断 / fence 包裹 / 嵌套截断）。**未做真实上游联调**——需带坏输出跑一次 `/api/agent-b-v2/generate` 才能确认模型确能修好。
- **sub 复核（ayuan-aide，只读）**：本轮改动与四份留痕 **20/20 全部对得上**，无第二套真相；另报 7 处冲突。已修其一：`diagnostic.retried` 原为常量 `MAX_RETRIES > 0`（恒 true），改为 `attemptsUsed > 1` 并补 `attempts` 计数。**未修**：板书字号三处不一致（见下条风险登记，待拍板）。

## 2026-09-17 输出物合格标准（盲测清单）落真源 + 发现 startCoord 未被消费（已执行·文档层）
- **起因（用户）**：要定义输出物合格标准——**一个没有上下文的 Agent 只凭这份 JSON + `row-player.html`，就能完整生成任意一道题的板书**；字体 jianjian/乔木都可；范围直接照搬输出物里的"本题目参数信息"（四区范围 + stage 参数）。
- **取证（逐条读代码，非记忆）**：`row-player.html` 的 `normData/normRow`（975-973 行）是真实消费契约——顶层只消费 `projectCode / problemText / boardPlan / rows`；row 消费 `stage / mp3|audio|audioUrl|voice / audioDurationMs / duration / speech / board{content,startDelay|triggerKeyword} / actionSpec`；`resolveTagAnchor`（276-286 行）以四个 Label 为标签落点真源；`boardLayout.js:152/187/219` 三种 `layoutMode` 各自产出四区 + 四 Label + canvas + image。
- **新发现（P0，此前未登记）**：`compile()` 组 board 计划项（310-311 行）**没有传 `coord`**，而 `drawWriting` 读 `task.coord`（616 行）→ `parseCoord(undefined)` → 退化硬编码默认 `{x:8,y:44}`。**带不带 `board.startCoord`，板书都叠在同一点**，不同题目无法各自排布 → 盲测必挂。
- **改动（只动唯一真源，不建第二套）**：
  1. `public/deliverable/deliverable.schema.json`：顶层 required 升为 `apiSpecVersion / projectCode / problemText / boardPlan / rows`；新增 `$defs.boardPlan`（canvas 1726×980 常量 + layoutMode 三值 + 四区 + 四 Label + image）与 `zoneBox`/`labelBox`；row 的 `stage` 收成四值 enum；新增 `mp3` 字段；`board.startCoord` 补 `[x%, y%]` 正则与必填说明。
  2. `public/deliverable/DELIVERABLE_API_SPEC.md`：新增第七节「盲测合格标准」——三层必带清单（题目层 / row 层 / 验收六问）+ 阻断项表 + 最小可播 JSON 骨架。
- **排除项**：**未改 `row-player.html` 代码**（渲染落点属画布观感，且修复方案需拍板）；未改 `dist/`（构建产物，下次构建同步）；未统一步板书字号（待拍板）。
- **验证结果**：`node` 解析 schema 通过（required 5 项、boardPlan required 10 项、stage 四值 enum、startCoord 已登记）。**未做运行时点检**（渲染链路未改，点检无意义）。
- **接力棒**：待用户拍板后修 `compile()` 传 `coord`（优先级 `board.startCoord` > `boardPlan[stage 区]` 左上角 > 模板常量，与 `resolveTagAnchor` 三层回退对齐），改完再用不同 `layoutMode` 产物人工点检验收六问。
## 2026-09-17 PM prompt.js 规范对齐审查 + 过期口径清理（已执行·代码层）
- **起因（用户）**：全面审查前端处理逻辑，删除过期的处理记录，确保代码逻辑与最新 prompt.js 规范完全对齐，围剿所有遗留陈旧信息块。
- **基准**：`src/agent-b-v2/prompt.js`（399 行）：三工具全量（rough-notation circle/underline/highlight + rough-line + rough-arrow，坐标一律百分比 0-100）；audioUrl/audioDurationMs 程序回填；模型不输出坐标（自然段落排版 + zoneAnchors 仅感知 + actionSpec 落点）；落笔时机 startDelay/triggerKeyword 二选一。
- **修复（6 文件）**：
  1. `src/agent-b-v2/AgentBDirect.vue`：parseBoard 补 triggerKeyword 提取（原只解 startDelay → 编辑/导出链路丢触发词）；updateBoardContent 落笔时机二选一透传（原构造 {content,startDelay} 抹掉 triggerKeyword）。
  2. `src/lib/speechMarkdown.js`：parseBoardField 删「[x%,y%] 坐标前缀剥离」正则（prompt.js 已声明模型不输出前缀；现存 handoff/board-result JSON 无前缀数据，安全）。
  3. `src/agent-b-v2/serializeDeliverableState.js`：board 序列化改 boardTiming 二选一（triggerKeyword 优先透传，无则 startDelay；timing.js:133-134 已支持消费）。
  4. `row-player.html` 10 处：DEMO hint + 字段表对齐（3 工具 + 二选一 + startCoord 可选三层回退口径）；3 处过期「一期/二期」注释清除；字号 42→35 ×4（drawWriting size / fonts.load / measureText ×2，对齐 stepHandoff.js BOARD_FONT_SIZE 真源）；规格批注「手写尖尖体」→「平方乔木体」（对齐 HAND_FONT:376 实际字体栈）。
  5. `public/deliverable/DELIVERABLE_API_SPEC.md`（+ dist 副本 md5 同步）：7.2 startCoord 改「○ 可选」+ actionSpec 3 工具；7.4 改「过期结论更正表」（coord 阻断 + 字号不一致两项标作废），仅存图片题阻断项。
- **审查结论（无需改动）**：check-agent 四文件已与 prompt.js 对齐（无分期口径；check prompt.js:200 已是「不再提坐标」新口径；:97-98 三工具校验；contract.js:38 board 整体透传不剥 triggerKeyword；asrPolish 无过期口径）；superFilter.js 无坐标前缀残留（字号硬编码此前已改 import stepHandoff 常量）。
- **留痕**：PROJECT_STATE 3 处（coord P0 已修 / 字号 P1 已拍板 A 案 / 硬编码密钥 P0 按用户指示注销——演示密钥绝不删）、DECISIONS 2 处（#012 actionSpec 口径 / 已知阻断段）、MEMORY.md 字号条目、memory/2026-09-17.md 追加「规范对齐」段（含过期结论更正表）。
- **验证**：`npm run build` ✓ 1.28s（chunk 警告与历史基线一致）；row-player.html script 提取 `node --check` ✓；grep 无 42px / 一期口径残留；SPEC public/dist md5 一致。
- **接力棒**：① 图片题 P0 仍未闭环（normData 零消费 screenshotUrl/sourceImageUrl/boardPlan.image——SPEC 7.4 仅存阻断项）；② 改模板≠改产物：35px 字号与 3 工具口径需重生成产物后按验收六问人工点检（含 35px 手写感观感确认）。

## 2026-09-17 PM 图片题 P0 数据通链修复（已执行·代码层）
- **起因**：SPEC 7.4 仅存阻断项「图片题无图」——screenshotUrl/sourceImageUrl/boardPlan.image 在 row-player normData 零消费，renderDeliverableHtml 不处理图片，且 /pic/ 相对路径违反脱环境铁律。
- **取证**：现存产物 deliverable-deliverable-1789584993949.json 顶层带 screenshotUrl=/pic/shot-*.jpg + boardPlan.image={x:6,y:13.2,w:88}（数据链完备只差消费）；boardLayout 三种 layoutMode 均产出 image 坐标；public/pic 与 dist/pic 均为空（运行时数据缺失）。
- **改动（2 文件 + 产物重生成）**：
  1. `server/renderDeliverableHtml.js`：新增 `inlineDeliverableImages`（screenshotUrl/sourceImageUrl 的 `/pic/` 相对路径 → base64 data URL；缺文件保留原值+告警不炸；png/webp/jpeg mime 判别）+ render 接线 + 产物总长 1MB 体积护栏告警。
  2. `row-player.html` ×6 处：normData 增 `screenshotUrl`（优先，兼容 sourceImageUrl）；注入装载区透传；`PROBLEM_IMG` 全局 + `loadProblemImage()`（异步一次加载，onerror 静默跳过）；`load()` 统一挂载（注入/apply/导入三路径全覆盖）；render(t) 题目文字后幂等绘制 `boardPlan.image` 落区（高度按纵横比 clamp 底界 96.33%）；fJson 导入补 screenshotUrl+boardPlan 透传（顺带修复导入丢 boardPlan 的缺口）。
  3. `public/deliverable/current.html` 离线重生成。
- **验证**：① 伪造图片单测：base64 内嵌 ✓ / 死链保留原值+告警 ✓ / 测试文件已清理 ✓；② `npm run build` ✓（chunk 警告与基线一致）；③ node --check row-player 主脚本 + renderDeliverableHtml ✓；④ current.html 重生成 117KB < 1MB，35px 字号/resolveBoardCoord 三层回退/题图链路/平方乔木体批注 4/4 落地 ✓。
- **边界确认（红线）**：不动 boardLayout 落座算法（只读其 boardPlan.image 产出）；不动 1726×980/纸白/边框（图片画在画布内容区）；row-player 为唯一真源可直接增强（同 coord/字号先例）。
- **接力棒**：public/pic/ 现为空——补真实截图文件后图片题自动恢复；图片题产物需人工点检图片落区视觉效果（纵横比/不压题目文字）。

## 2026-09-17 PM GitHub 备份（分支 backup/2026-09-17-full）
- **动作**：全量快照推送至 github.com/zo4xia/2222 新分支 backup/2026-09-17-full；排除平台中间产物 historical_context.txt（.git/info/exclude 本地排除，不入仓库）。
- **快照内容**：项目完整性恢复（清 React 脚手架残留 109 文件）、prompt.js 规范对齐 6 文件修复、图片题 P0 数据通链（PROBLEM_IMG 装载器 + renderDeliverableHtml base64 内嵌 + 1MB 体积护栏）、productionServer 静态资源流式改造（createReadStream 替换 readFileSync，1核2G P0）、lint 依赖补齐（eslint 10.8.1 精确版本避开镜像滞后）+ 872 warnings 自动修复（红线文件零改动，row-player 意外 checkout 后经 current.html 产物逆向恢复并字节级幂等验证）、阶段 A/B 深度扫描与遗留治理文档新增。
- **安全口径**：仓库内密钥仅含演示专用 sk-fish（用户红线要求保留）；GitHub token 一次性内联推送，未持久化于 remote config。
