# 阶段A·深度扫描报告（X射线级解析）

> 生成：2026-09-17 PM · 基线：npm run build ✓ 1.28s · 本报告为单一真源汇总，历史根目录文档（dataflow_diagram / module_dependency_graph / risk_matrix / diagnostic_report / calibrated_prd）为早期产物，冲突处以本报告与 PROJECT_STATE/DECISIONS 为准。

## 1. 四层目录树（职责标注）

```
lite-player/                                 【工程根 = clean-package 口径】
├─ index.html / agent-b-v2.html / board-preview.html   【vite 三入口】
├─ row-player.html                           【🔴播放器唯一真源·不进build·静态lint+人工点检】
├─ lite-player.html                          【⚪孤儿文件 P2·全仓0引用·作废未删】
├─ handwrite-compare (3).html                【⚪板书字风格真源参照】
├─ vite.config.js                            【🔵项目自有配置·多入口·dev:3000】
├─ vite.config.ts                            【🔵平台管理文件·禁改（Event205）·优先级低于.js】
├─ eslint.config.js / package.json           【🔵工程配置】
├─ PROJECT_STATE / DECISIONS / ENGINEERING_LOG / calibrated_prd / diagnostic_report / dataflow_diagram / module_dependency_graph / risk_matrix / decoupling_strategy / resource_list / project_initial_state .md   【📄工程留痕+历史分析】
├─ api/                                      【🔵Vercel serverless 薄壳→转调 server/ handler】
│  ├─ agent-b-v2/generate.js  check-agent/  recognition/problem.js  cleanup.js
├─ server/                                   【🟣Node 原生 HTTP 后端·零框架·1核2G目标】
│  ├─ productionServer.js                    【聚合入口·P0: readFileSync整文件进内存待流式】
│  ├─ agentBV2Handler.js(474)                【Agent B 编排：prompt.js注入+buildRepairHint回灌】
│  ├─ recognitionHandler/recognitionPrompt   【Agent A 题目识别】
│  ├─ checkAgentHandler.js(465)              【质检编排：asrPolish+contract白名单】
│  ├─ deliverableStoreHandler.js(510) + renderDeliverableHtml.js 【交付物存取+模板注入】
│  ├─ fishAudioHandler.js(389)               【TTS·🔴演示密钥DEFAULT_API_KEYS绝不删】
│  ├─ handoffStoreHandler / knowledgeRefineHandler / agentAKnowledge / screenshotStoreHandler / cleanupHandler / boardResultStore / http.js / docReferences.js / proxySelfCheck / smokeTest / agentAKnowledgeSelfCheck
├─ src/
│  ├─ main.js → App.vue                      【主应用链】
│  ├─ components/
│  │  ├─ Step1Entry.vue(1502)                【🔴A画布落座链·核心资产禁改】
│  │  ├─ BoardContentLayer.vue(953)          【🔴测高落位渲染·核心资产禁改】
│  │  ├─ VisualTimeline.vue(609) / RealBoardPreview.vue(303) / ProcessLoadingModal.vue(514)【🔴loading态禁改】/ GlobalPulseLoading.vue(403)【🔴loading态禁改】/ QhPageHeader.vue
│  ├─ utils/
│  │  ├─ boardLayout.js(287)                 【🔴A画布落座算法·绝对禁改】
│  │  ├─ superFilter.js(336)                 【🟣文本过滤唯一真源·字号import stepHandoff】
│  │  └─ canvasCoords / lectureRecorder / mathText
│  ├─ services/
│  │  ├─ stepHandoff.js(306)                 【🟣字号真源 BOARD_FONT_SIZE=35 + handoff序列化】
│  │  └─ recognitionClient / deliverableService / ttsService / cleanupService / knowledgeRefineService / globalLoading / agentAKnowledge
│  ├─ agent-b-v2/
│  │  ├─ AgentBDirect.vue(168KB)             【Agent B 工作室主组件·11处fetch】
│  │  ├─ prompt.js(399)                      【🟣Agent B 系统提示词唯一真源·规范基准】
│  │  ├─ prompt-v3-draft.js(488)             【⚠️v3草稿·未进主链·阶段B插旗候选】
│  │  ├─ contract.js(207) / service.js / DirectFlow.vue / timing.js(320)【exclusiveExecutionPlan互斥排程】/ serializeDeliverableState.js【board二选一透传·本轮修复】/ knowledgeRefinePrompt.js / main.js
│  │  └─ skills/
│  │     ├─ liyongle-elementary/             【李永乐知识包：persona/four-rings/speech-rules/board-rules/coordinate-rules/output-format/examples】
│  │     ├─ prompt-v3-draft/                 【⚠️v3草稿配套·阶段B插旗】
│  │     └─ default-fallback/
│  ├─ check-agent/                           【质检：prompt.js(235)·已对齐规范 / contract.js(ALLOWED_FIELDS) / asrPolish.js / service.js】
│  ├─ board-tools/                           【板书工具×7：catalog/timing/drawIntent/handActionScheduler/roughDrawing/roughNotation/textTargetRegistry】
│  ├─ board-preview/                         【board-preview.html 入口链】
│  └─ lib/                                   【speechMarkdown(🟣board解析·本轮删坐标前缀) / mathAsrConverter / registerAntd / agentBApiConfig / checkAgentApiConfig / userApiConfig / apiConfigStoreFactory】
├─ public/deliverable/                       【⚪交付产物区：DELIVERABLE_API_SPEC.md(🟣交付合同) + deliverable.schema.json + 产物html/json】
├─ public/{handoff,board-result,pic,audio-cache,fonts}  【⚪运行时写public共6处·P2挂起】
├─ dist/                                     【⚪构建产物·不手改】
├─ doc/knowledge-a.compact.json              【知识资产】
├─ memory/                                   【📄MEMORY.md + 日志 + ontology】
├─ scripts/                                  【writer.cjs+writer.js ⚠️双版本Level1候选】
└─ docs/                                     【prd.md + DESIGN.md + 本报告】
```

## 2. 前后端 API 全文档（12 路由）

| 路由 | server handler | 前端调用方 | 职责与要点 |
|---|---|---|---|
| POST /api/recognition/problem | recognitionHandler + recognitionPrompt | recognitionClient.js ← Step1Entry | Agent A 题目识别（文本/图片），产出 problemText + 板书素材 |
| POST /api/agent-b-v2/generate | agentBV2Handler.js | agent-b-v2/service.js ← AgentBDirect.vue:166 | Agent B rows 生成：注入 prompt.js + skills 知识包；坏输出 buildRepairHint 回灌修缮（决策#011，MAX_RETRIES=1） |
| POST /api/check-agent/check | checkAgentHandler | check-agent/service.js:47 | 质检 rows（prompt 235 行：三工具校验/不再提坐标口径） |
| POST /api/check-agent/apply | checkAgentHandler | service.js:96 | 应用修复：ALLOWED_FIELDS=speech/board/actionSpec；board 整体替换（contract.js:38，triggerKeyword 不剥离） |
| POST /api/check-agent/revert | checkAgentHandler | service.js:108 | 回滚修复 |
| GET/POST /api/handoff(+/list) | handoffStoreHandler.js | stepHandoff.js | 步骤交接数据存取（A→B 传递题目+boardPlan） |
| * /api/knowledge/ | knowledgeRefineHandler + agentAKnowledge | knowledgeRefineService / agentAKnowledge | 知识库检索与精炼 |
| GET/POST /api/deliverable | deliverableStoreHandler.js | deliverableService + AgentBDirect 直接 fetch | 交付物存取；renderDeliverableHtml 将 rows 注入 row-player.html 模板（zoneAnchors=boardPlan\|\|zoneAnchors） |
| POST /api/screenshot | screenshotStoreHandler | Step1Entry | 题目截图存取 |
| POST /api/tts | fishAudioHandler.js | ttsService + AgentBDirect 直接 fetch | Fish Audio TTS；🔴DEFAULT_API_KEYS 演示密钥原样保留 |
| POST /api/cleanup | cleanupHandler.js | cleanupService | 产物清理（保留 current.json/SPEC/schema） |

补充：AgentBDirect.vue 内另有 10 处直接 fetch（tts/音频缓存/图片等，行 724-1462），未全部收敛到 service 层（阶段D 解耦候选）。

## 3. 业务逻辑流映射图（Mermaid）

```mermaid
flowchart TD
  subgraph FE[前端 Vue3]
    S1[Step1Entry 题目输入<br/>文本/图片] -->|/api/recognition/problem| RA[Agent A 识别]
    RA --> BL[boardLayout.js 落座<br/>🔴三种layoutMode→四区+四Label]
    BL --> BCL[BoardContentLayer 测高落位]
    S1 --> SH[stepHandoff.js<br/>🟣字号35+handoff序列化]
    SH -->|/api/handoff| HS[handoff存储]
    AB[AgentBDirect 工作室] -->|/api/agent-b-v2/generate| GEN[Agent B 生成]
    GEN --> ROWS[rows: speech+board+actionSpec]
    ROWS --> SF[superFilter 🟣符号降级防豆腐块]
    SF --> VT[VisualTimeline + timing.js<br/>exclusiveExecutionPlan互斥排程]
    SF -->|/api/check-agent/*| CHK{Check Agent 质检}
    CHK -->|apply修复·白名单三字段| SF
    ROWS --> SER[serializeDeliverableState<br/>board二选一透传]
    SER -->|/api/deliverable| DS[deliverable存储]
  end
  subgraph BE[服务端 Node]
    GEN -.->|坏输出| BRH[buildRepairHint 回灌修缮 #011]
    DS --> RDH[renderDeliverableHtml<br/>rows注入row-player模板]
    TTS[fishAudioHandler TTS<br/>🔴演示密钥] -->|audioUrl回填| ROWS
  end
  subgraph DL[交付]
    RDH --> DEL[public/deliverable/*.html<br/>CDN字体+base64素材<1MB]
    DEL --> BT[盲测线：零上下文Agent+JSON+row-player<br/>演完整任意一题=合格]
  end
```

## 4. 六维性能评估表 + 依赖版本矩阵

| 维度 | 评级 | 事实依据 |
|---|---|---|
| 性能 | ⚠️P0×1 | productionServer.js:98 readFileSync 整文件进内存（1核2G OOM 风险；模板已 5.26MB→0.11MB 降压一个数量级，流式改造待排期）；前端 preload-helper chunk 1.38MB（gzip 420KB）超 500KB 警告（历史基线一致） |
| 可用性 | ✅ | loading 三件套完备（ProcessLoadingModal/GlobalPulseLoading，🔴禁改）；无音频走虚拟时钟不卡死；盲测线标准已立（SPEC 第七节验收六问） |
| 依赖复杂度 | ✅ | 运行时仅 6 包；roughjs 4.6.6 + rough-notation 0.5.1 双栈（notation 底层即 roughjs）；后端零框架原生 http |
| 安全性 | ⚠️内部工具定位 | 演示密钥按用户指示原样保留（🔴绝不删）；无鉴权层（内部工具定位，非公网产品）；API 密钥可前端配置（apiConfigStoreFactory 三套） |
| 可维护性 | ⚠️P1 | 单一真源清单已立（字号 stepHandoff / 过滤 superFilter / Label boardPlan / 规范 prompt.js）；三文档留痕制度运行中；遗留大文件：Step1Entry 1502 行、BoardContentLayer 953 行、AgentBDirect 168KB（阶段B 治理候选，受红线保护部分禁拆） |
| 兼容性 | ⚠️P1 | Vercel 部署缺口：vercel.json 只覆盖 6 个 api 入口（tts/handoff/deliverable/knowledge/screenshot/cleanup 缺失→线上404）；本地 dist/fonts 为历史资产已让位 CDN |

**核心依赖版本矩阵**：vue ^3.5.39 · ant-design-vue ^4.2.6 · @ant-design/icons-vue ^7.0.1 · katex ^0.18.4 · roughjs ^4.6.6 · rough-notation ^0.5.1 ｜ dev: vite ^8.1.1 · @vitejs/plugin-vue ^6.0.7 · eslint ^10.8.1 · eslint-plugin-vue ^10.10.0

## 5. 需求校准表（文档 vs 代码差异）

| # | 类型 | 差异/发现 | 状态 |
|---|---|---|---|
| 1 | ✅已对齐 | compile coord 三层回退、字号统一 35px、triggerKeyword 全链路透传、actionSpec 三工具口径、坐标前缀剥离删除 | 本轮闭环（见 ENGINEERING_LOG 2026-09-17 PM） |
| 2 | 🔴P0未闭环 | 图片题断链：AgentBDirect.vue:1293/1297 写入 sourceImageUrl/screenshotUrl，serialize 顶层带出，但 row-player normData(:975-983) 只取 4 顶层字段零消费 → 图片题交付页缺图 | SPEC 7.4 仅存阻断项，阶段D 修复 |
| 3 | ⚠️文档差 | prompt-v3-draft.js(488行)+skills/prompt-v3-draft/ 存在但主链消费 prompt.js(v2 399行)——「第二套真相」风险 | 阶段B 插旗（保留/归档/删除待拍板） |
| 4 | ⚠️文档差 | PROJECT_STATE「row-player 排版与落笔规则全页统一」P1 尚未执行 | 阶段C/E 处理 |
| 5 | ⚠️Level1 | scripts/writer.cjs 与 writer.js 双版本并存 | 阶段B 治理 |
| 6 | ⚪P2登记 | lite-player.html 孤儿（0 引用）；上层仓库脏区（决策#003 不维护） | 已登记待拍板 |
| 7 | 🔍隐藏逻辑 | 坐标真源链：boardLayout 三 layoutMode → boardPlan 四区+四Label → resolveTagAnchor/resolveBoardCoord 三层回退（装载即读取，禁内容反推，决策#010） | 已固化 |
| 8 | 🔍隐藏逻辑 | timing.js exclusiveExecutionPlan：口播/板书/动作互斥排程（车同轨·书同文）；triggerKeyword 语义已入排程（timing.js:133） | 已固化 |
| 9 | 🔍隐藏逻辑 | AgentBDirect 11 处直接 fetch 未收敛 service 层 | 阶段D 数据通链治理 |

—— 阶段A 收官。接力：阶段B 以本报告 §5 #3/#5 为首批插旗对象；阶段D 以 #2（图片题 P0）与 #9（fetch 收敛）为主攻。
