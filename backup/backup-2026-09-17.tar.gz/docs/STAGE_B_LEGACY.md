# 阶段B·遗留识别与分级治理报告

> 生成：2026-09-17 PM · 方法：三级识别 + 六步心法（插旗标记→最小单元划分→逐模块提取→改一测一）· 原则：非破坏性消化技术债，受红线保护对象只插旗不拆。

## 1. 三级识别清单（含取证）

### Level 1 · 命名混乱 / 重复实现

| 编号 | 对象 | 取证 | 处置 |
|---|---|---|---|
| L1-1 | `scripts/writer.cjs` + `scripts/writer.js` | 两文件内容 100% 相同（一行式 base64→utf8 写盘工具）；全仓零 import/require；构建不依赖（build ✓ 已验证） | 🔴插旗待拍板：建议保留 `.cjs`（CommonJS 语义明确）删 `.js`；因疑似人工/外部流程工具，不擅自删 |
| L1-2 | 根目录 `lite-player.html` | 全仓 0 引用；MEMORY 红线已声明「作废孤儿」 | 🔴插旗：PROJECT_STATE P2 已登记，删除待用户拍板 |

### Level 2 · 单文件超限 / 命名误导

| 编号 | 对象 | 取证 | 处置 |
|---|---|---|---|
| L2-1 | `prompt-v3-draft.js`(488行) + `skills/prompt-v3-draft/` | **非死代码**：`skills/index.js:6,12` 合法注册，`agentBV2Handler.js:194-195` 按 skillId 动态选择，AgentBDirect UI 可切换；但 "draft" 命名易被误判为遗留草稿 | 🟡插旗：保留（合法可选实验 skill）；命名降误判方案待拍板（如 `experimental-v3`）。**规范真源不受影响**：默认链 default-fallback → `prompt.js`(399行) AGENT_B_V2_SYSTEM_PROMPT，handler:3 亦直引 |
| L2-2 | `Step1Entry.vue`（1502 行） | 🔴红线：A 画布落座链核心资产，绝对禁止改动/精简/重写 | 🔴只插旗不拆（红线保护区） |
| L2-3 | `BoardContentLayer.vue`（953 行） | 🔴红线：测高落位渲染核心资产 | 🔴只插旗不拆（红线保护区） |
| L2-4 | `AgentBDirect.vue`（168KB 巨石） | 业务+UI 混合；11 处直接 fetch 绕过 service 层（:123-1462） | 🟡可治理区：最小单元=TTS 控制段 / fetch 收敛段 / serialize 调用段 → 阶段D 执行 |
| L2-5 | `server/deliverableStoreHandler.js`（510 行） | store 逻辑 + spec 读取 + 清理规则混合 | 🟡可治理区：待阶段C/E 排期拆分 |

### Level 3 · 业务 UI 混合 / 无测试

| 编号 | 对象 | 取证 | 处置 |
|---|---|---|---|
| L3-1 | AgentBDirect 直接 fetch ×11 | 绕过 service 层，数据流未收敛（阶段A §5 #9） | 🟡阶段D 主攻项 |
| L3-2 | 全仓无单元测试 | 仅有 `server/smokeTest.js` / `proxySelfCheck.js` / `agentAKnowledgeSelfCheck.js` 三个自检脚本；row-player.html 按红线只做静态 lint + 人工点检 | 🟡登记：测试引入属增量决策，待用户拍板是否值得投入（当前以盲测线+构建+自检三重验收替代） |

## 2. 本轮实际治理记录（改一测一）

| 动作 | 文件 | 验证 |
|---|---|---|
| board 落笔时机二选一透传（最小治理：序列化层） | AgentBDirect.vue / serializeDeliverableState.js / speechMarkdown.js | npm run build ✓ 1.28s |
| row-player 过期口径清理（字号/注释/帮助区） | row-player.html ×10 处 | node --check ✓ + grep 零残留 |
| 过期结论更正（不静默覆盖） | PROJECT_STATE ×3 / DECISIONS ×2 / MEMORY ×1 / SPEC 7.4 | md5 同步 public↔dist ✓ |

**未执行任何删除**（全部插旗待拍板）——符合非破坏性原则。

## 3. 解耦边界示意图（保护区 / 缓冲区 / 自由区）

```mermaid
flowchart LR
  subgraph RED[🔴红线保护区·只插旗不拆]
    BL[boardLayout.js 落座算法]
    SE[Step1Entry.vue]
    BCL[BoardContentLayer.vue]
    LD[loading 态组件群]
    RP[row-player.html 渲染内核]
    FK[fishAudioHandler 演示密钥]
  end
  subgraph TRUTH[🟣真源区·改动须过单一真相审查]
    PJ[prompt.js 规范]
    SH2[stepHandoff.js 字号]
    SF[superFilter.js 过滤]
    BP[boardPlan 四Label 定位]
    SPEC[DELIVERABLE_API_SPEC 交付合同]
  end
  subgraph FREE[🟡自由治理区·按六步心法推进]
    AB[AgentBDirect 可拆单元<br/>TTS段/fetch收敛]
    SV[server handler 拆分<br/>deliverableStore 510行]
    FC[fetch→service 收敛×11]
    IMG[图片题渲染链补全 P0]
  end
  RED -->|依赖不改| FREE
  TRUTH -->|消费不改语义| FREE
```

## 4. 接力棒

1. 阶段C：以本报告 §3 边界图为基础出《结构固化文档》（>300 行组件 / >500 行服务拆分排期，红线区除外）。
2. 阶段D：主攻 L3-1（fetch 收敛）+ 图片题 P0。
3. 用户拍板项汇总：L1-1 writer 双版本删一 / L1-2 lite-player.html 删除 / L2-1 v3-draft 重命名 / L3-2 是否引入测试框架。
