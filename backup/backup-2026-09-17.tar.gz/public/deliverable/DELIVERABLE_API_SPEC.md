# 教学课件与音画微课交付物 API 规范（v2.0.0）

> 校验契约：`/deliverable/deliverable.schema.json`
> 消费对象：三方 API 接入方、下游课件/画布 Agent（自行安装配套 skills 后按本规范消费）
> 验收标准（盲测线）：**只给一个 deliverable JSON，Agent 能否顺利生成教学板。能 = 合格；不能 = 不合格。**
>
> **合格 = 一个零上下文 Agent 拿到这份 JSON + `row-player.html` 模板，就能把任意一道题的板书完整、正确地演出来。**
> 换位自检：如果我只拿到这一个 JSON、别的什么都不知道，我缺什么就演不出来？缺的那些，就是必须输出的参数。

## 一、五条核心消费规则

1. **每个 row 是一组独立的原子播放单元**，row 之间顺序衔接。
2. **speech 语音贯穿全程**：每 row 的口播从 `startOffsetMs=0` 持续到 row 结束。
3. **板书（board）与动作（actionSpec）在时间上绝对互斥**：一维时间线上没有交集，动作只插在板书前后的时间缝隙里（单手操作模型）。
4. **动作时长严格定量 1~2 秒**，语义上是口播句子中的标点停顿。
5. **直接消费每个 row 的 `exclusiveExecutionPlan` 数组**，按 `startOffsetMs` 依次触发（`plan` 为其兼容别名）。

## 二、顶层字段

| 字段 | 类型 | 说明 |
|---|---|---|
| `projectCode` | `YYYYMMDD-HHMMSS-SSS` | 项目编码（服务端唯一真源生成）；归档文件 = `deliverable-<projectCode>.json/.html` |
| `problemText` | string | 题目全文 |
| `sourceImageUrl` / `keepOriginal` | string / bool | 原题图片与是否贴入题目区（图片题） |
| `topicLayout` / `boardPlan` | object | Agent A 画布落座布局与四区坐标锚点 |
| `screenshotUrl` | string | 原题截图持久资产地址 |
| `specAnnotation` | string | 画布规格批注：1726×980、比例、题目/板书字号、四区坐标区间、越界与手稿风格 |
| `meta` | object | problemType / boardFocus / gradeLevel / knowledgeTitle / canvasSize |
| `stats` / `checkInfo` | object | 统计与 Check Agent 校对信息 |

## 三、row 字段（核心）

| 字段 | 说明 |
|---|---|
| `stage` | 阶段名（题目/分析/解答/总结…） |
| `speech` | 口播稿全文（保留口语毛料，仅清错误转义） |
| `audioUrl` | 本地持久化音频地址（`/audio/*.mp3`）；空串=未生成，按估算时长走无声时钟 |
| `audioDurationMs` | 真实音频时长（毫秒，时长第一真源）；null=未合成 |
| `duration` | 秒。`audioDurationMs/1000` > 估算（160字/分）> 板书动作最晚结束时间 |
| `board.content` / `board.lines` | 板书全文 / 按行数组（已过车同轨清洗：一行一个、写完一个再写一个） |
| `board.triggerKeyword` 或 `board.startDelay` | 落笔触发方式：念到关键词落笔，或语音起手延迟 N 秒（二选一） |
| `actionSpec[]` | 画布动作规格（圈画/擦除等），每个 1~2 秒 |
| `exclusiveExecutionPlan[]` | 单手互斥时序计划，按 `startOffsetMs` 升序 |
| `timingPolicy` | 恒为 `speech-full-board-action-mutually-exclusive` |

## 四、exclusiveExecutionPlan 元素

`type` 三种：`speech`（role=narration_full，带 text）、`board`（role=writing，带 content/lines/triggerKeyword）、`action`（role=punctuation_pause，带 index/action）。公共字段：`startOffsetMs` / `durationMs` / `endOffsetMs`。

## 五、时长与音频规则

- 时长真源优先级：`audioDurationMs`（毫秒）> `duration`（秒）> 语速估算（160字/分）> 板书动作最晚结束时间。
- 音频必须完整播放（以 `ended` 事件为准），禁止估算截断；地址失效时降级为虚拟时钟继续推进，不卡死。
- 空串 `audioUrl` = "待生成"，不得伪造时长。

## 六、交付物形态

| 产物 | 说明 |
|---|---|
| `deliverable-<projectCode>.json` | 本规范定义的规格 JSON（盲测输入） |
| `deliverable-<projectCode>.html` | 与 JSON 配对的自包含单页（row-player 模板 + 注入 `window.__INITIAL_DELIVERABLE__`），离线双击即播 |
| `current.json` / `current.html` | 当前活跃产物指针与镜像 |

## 七、盲测合格标准：JSON 里到底必须有什么

判定口径：**零上下文 Agent + 本 JSON + `row-player.html`**，能演出任意一道题 = 合格。
按"演不出来的就必填"倒推，分三层。

### 7.1 第一层：题目层（没有它，板上一片空白）

| 必带 | 字段 | 演不出会怎样 |
|---|---|---|
| ✔ | `problemText` | 题目原文一打开就该印在板上（30px 印刷体、行高 1.65、考卷式）。缺 = 无题可讲、圈画动作全部落空 |
| ✔ | `boardPlan.canvas{w:1726,h:980}` | 画布锁定尺寸，缺则百分比坐标换算基准不稳 |
| ✔ | `boardPlan.layoutMode` | `portrait` / `portrait-left-image` / `landscape-top-image`。四区与标签坐标随它变，缺 = 落座模式无从判断 |
| ✔ | `boardPlan.question` | 题目原文落座区（x/y/w + fontSize）。缺 = 题文默认落点，容易压住板书 |
| ✔ | `boardPlan.analysis` / `solution` / `summary` | **四区范围**：板书该写在哪、边界在哪。缺 = 板书越界或压字 |
| ✔ | `boardPlan.topicLabel` / `analysisLabel` / `solutionLabel` / `summaryLabel` | **stage 贴纸定位（决策 #010）**：四枚标签落点唯一真源，直接照搬导出物，禁止写死、禁止用板书内容反推。缺 = 标签错位 = 书写区看着就错 |
| 图片题 | `boardPlan.image` / `sourceImageUrl` / `screenshotUrl` | ✅ 已修复（2026-09-17 PM）：装载即把题图印在 `boardPlan.image` 落区（x/y/w 百分比，高度按纵横比 clamp 画布底）；服务端 `renderDeliverableHtml` 自动把 `/pic/` 相对路径内嵌 base64（脱环境铁律）。**前置条件：源图须存于 `public/pic/`，缺失时保留原值、播放器静默跳过图片层（文字板书不受影响）** |

> 一句话：**四区范围 + 四个 stage 标签坐标，就是"本题目参数信息"，必须整块照搬导出物，缺一不可。**

### 7.2 第二层：row 层（每一行讲什么、写在哪）

| 必带 | 字段 | 说明 |
|---|---|---|
| ✔ | `stage` | 只能 `题目/分析/解答/总结`。决定落区、贴哪枚标签、分析区红笔其余黑笔；取别的值 → 标签不显示 |
| ✔ | `speech` | 口播稿 = 字幕 = 无音频时的时长估算来源 |
| ✔ | `board.content` | 板书写什么，一行一个（`\n` 或数组均可）；题目行写空串 |
| ○ | `board.startCoord` | 可选。落笔起点 `"[x%, y%]"`；不写则渲染层按 boardPlan 该 stage 区自动落位（决策 #012 三层回退：startCoord > 区左上角 > 模板常量） |
| ✔ | `board.startDelay` 或 `board.triggerKeyword` | 落笔时机（二选一） |
| ✔ | `duration`（秒）或 `audioDurationMs`（毫秒） | 时长。真源优先级 `audioDurationMs > duration > 语速估算(160字/分) > 板书动作最晚结束时间` |
| ✔ | `mp3` | 配音地址，未生成写 `""` → 自动走无声虚拟时钟，不卡死。归一顺序 `mp3 > audio > audioUrl > voice` |
| ○ | `actionSpec[]` | 3 工具（与 prompt.js 对齐）：`rough-notation`（`circle`/`underline`/`highlight`，`target.exactText` 必须是已写出的文字，否则跳过）、`rough-line`、`rough-arrow`（坐标一律百分比 0-100） |

### 7.3 第三层：验收六问（人工点检清单）

1. 双击 HTML 有画面（底图/贴纸内嵌 base64，无本地相对路径请求）。
2. 题目原文一打开就印在 `boardPlan.question` 位置。
3. 四枚 stage 标签落点与 JSON 的四个 Label **完全一致**（换一份 `layoutMode` 的产物再验一次，落点必须跟着变）。
4. 各段板书落在自己 stage 的区内，不越界、不叠在一起。
5. 有音频时完整播完（`ended` 驱动）；无音频时虚拟时钟顺滑推进，不卡首行。
6. 特殊符号已按超级过滤器降级：乘写 `x`、除写 `\frac{}{}`、平方立方写 `²³`、`∵∴` 写中文（否则豆腐块）。

### 7.4 过期结论更正表（历史阻断项均已闭环，2026-09-17 PM 更新）

**以下三项已修复，原文作废：**

| 原结论（作废） | 修复证据 | 现状 |
|---|---|---|
| ~~`board.startCoord` 未被消费，所有板书叠在同一处~~ | `compile()` 已传 `coord: resolveBoardCoord(r, bp, r.stage)`；三层回退（startCoord > boardPlan[stage] 区左上角 +2%,+4% > 模板常量 {8,44}）与 `resolveTagAnchor` 同构落地 | ✅ 已闭环，7.3 第 4 问不再因此挂 |
| ~~板书字号三处不一致（35/42/1.5 倍），待拍板~~ | `row-player.html` 四处 42px 已统一 35px（drawWriting size / fonts.load 预热 / measureText 检测×2），规格批注同步更正字体名（平方乔木体） | ✅ 已统一，唯一真源 = `stepHandoff.js` BOARD_FONT_SIZE |
| ~~图片题无图：normData 零消费 screenshotUrl/sourceImageUrl/boardPlan.image~~ | normData 已提取 `screenshotUrl`（优先，兼容 `sourceImageUrl`）+ 注入/JSON 导入/load 三装载点 + render 幂等绘制 `boardPlan.image` 落区；`renderDeliverableHtml` 新增 `inlineDeliverableImages` 把 `/pic/` 相对路径自动内嵌 base64（脱环境铁律）+ 1MB 体积护栏告警 | ✅ 链路闭环；唯一前置 = 源图存于 `public/pic/`（缺失静默跳过图片层） |

### 7.5 最小可播 JSON（盲测样例骨架）

```json
{
  "apiSpecVersion": "2.0.0",
  "projectCode": "20260917-044037-387",
  "problemText": "题目原文，一打开就印在板上",
  "boardPlan": {
    "canvas": { "w": 1726, "h": 980 },
    "layoutMode": "portrait",
    "topicBottomPct": 30,
    "question":  { "x": 6,    "y": 13.2, "w": 44, "h": 22, "fontSize": 30 },
    "analysis":  { "x": 6,    "y": 41,   "w": 44, "h": 48 },
    "solution":  { "x": 54,   "y": 14,   "w": 40, "h": 44 },
    "summary":   { "x": 54,   "y": 69.5, "w": 40, "h": 22 },
    "topicLabel":    { "x": 5.7,  "y": 6.6 },
    "analysisLabel": { "x": 5.7,  "y": 34.5 },
    "solutionLabel": { "x": 53.7, "y": 6.6 },
    "summaryLabel":  { "x": 53.7, "y": 62 }
  },
  "rows": [
    {
      "stage": "题目",
      "speech": "口播稿，也是字幕",
      "mp3": "",
      "duration": 17.8,
      "board": { "startCoord": "[6%, 12%]", "startDelay": 0, "content": "" },
      "actionSpec": [
        { "tool": "rough-notation", "action": "circle",
          "target": { "exactText": "9", "occurrence": 1 } }
      ]
    },
    {
      "stage": "分析",
      "speech": "……",
      "mp3": "/audio/audio-xxxx.mp3",
      "audioDurationMs": 14600,
      "duration": 14.6,
      "board": { "startCoord": "[8%, 44%]", "startDelay": 1.8, "content": "第一行\n第二行" },
      "actionSpec": []
    }
  ]
}
```
